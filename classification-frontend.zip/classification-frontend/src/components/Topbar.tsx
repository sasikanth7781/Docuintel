"use client";

import { Box, Avatar, Typography, IconButton, Menu, MenuItem, Divider } from "@mui/material";
import { useState } from "react";
import PasswordDialog from "./PasswordDialog";
import SecureStorage from "react-secure-storage";
import { callPostApiWithData } from "@/api/api";
import { useSnackbar } from "@/components/snackbar";
import { useRouter } from "next/navigation";

export default function Topbar() {
    const name = (SecureStorage.getItem("name") as string) || "User";
    const email = (SecureStorage.getItem("email") as string) || "user@example.com";

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [openPassword, setOpenPassword] = useState(false);

    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();
    const refreshToken = SecureStorage.getItem("refreshToken") as string;

    const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => setAnchorEl(event.currentTarget);
    const handleMenuClose = () => setAnchorEl(null);

    const handlePasswordOpen = () => {
        setOpenPassword(true);
        handleMenuClose();
    };

    const handleLogout = () => {
        try {
            const onSuccess = (res: any) => {
                enqueueSnackbar("Logged out successfully.", { variant: "success" });
                SecureStorage.clear();
                router.push("/auth/login");
            };

            const onError = (err: any) => {
                enqueueSnackbar("Error while logging out.", { variant: "error" });
                SecureStorage.clear();
                //router.push("/auth/login");
            };

            callPostApiWithData(
                "logout",
                null,
                { refresh_token: refreshToken },
                onSuccess,
                onError
            );
        } catch (error) {
            enqueueSnackbar("Unexpected error during logout.", { variant: "error" });
            SecureStorage.clear();
            router.push("/auth/login");
        }

        handleMenuClose();
    };

    return (
        <Box
            sx={{
                height: 64,
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
                px: 3,
                backgroundColor: (theme) => theme.palette.background.paper,
                borderBottom: "1px solid",
                borderColor: (theme) => theme.palette.divider,
                position: "sticky",
                top: 0,
                zIndex: 1200,
            }}
        >
            {/* Avatar */}
            <IconButton onClick={handleMenuOpen}>
                <Avatar sx={{ bgcolor: (theme) => theme.palette.primary.main, width: 40, height: 40 }}>
                    {(name?.[0] || "U").toUpperCase()}
                </Avatar>
            </IconButton>

            {/* Menu */}
            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
                slotProps={{
                    paper: {
                        sx: {
                            p: 2,
                            minWidth: 280,
                            borderRadius: 3,
                            boxShadow: (theme) => theme.shadows[4],
                        },
                    },
                }}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
            >
                <Box mb={1}>
                    <Typography variant="subtitle1" fontWeight={700}>
                        {name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {email}
                    </Typography>
                </Box>

                <Divider sx={{ my: 1 }} />

                <MenuItem
                    onClick={handlePasswordOpen}
                    sx={{
                        borderRadius: 2,
                        mb: 0.5,
                        "&:hover": { backgroundColor: (theme) => theme.palette.primary.light },
                    }}
                >
                    Reset Password
                </MenuItem>

                <MenuItem
                    onClick={handleLogout}
                    sx={{
                        borderRadius: 2,
                        color: (theme) => theme.palette.error.main,
                        "&:hover": { backgroundColor: (theme) => theme.palette.error.light },
                    }}
                >
                    Logout
                </MenuItem>
            </Menu>

            <PasswordDialog open={openPassword} onClose={() => setOpenPassword(false)} />
        </Box>
    );
}
