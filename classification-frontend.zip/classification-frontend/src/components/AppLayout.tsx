"use client";

import React from "react";
import {
    Box,
    CssBaseline,
    Drawer,
    List,
    ListItemButton,
    ListItemText,
    Typography,
    useTheme,
} from "@mui/material";
import { usePathname } from "next/navigation";
import Link from "next/link";
import Topbar from "@/components/Topbar"; // Using your working Topbar component

// ✅ Admin & Customer Menus (dynamic routing)
const adminMenu = [
    { label: "Dashboard", path: "/admin/dashboard" },
    { label: "User Management", path: "/admin/users" },
    { label: "System Settings", path: "/admin/settings" },
    { label: "Reports", path: "/admin/reports" },
];

const customerMenu = [
    { label: "Dashboard", path: "/user/dashboard" },
    { label: "Data Extraction", path: "/user/data-extraction" },
    { label: "OCR Settings", path: "/user/ocr-settings" },
    { label: "Policies", path: "/user/policies" },
];

// ✅ Unified App Layout for Admin + User
export default function AppLayout({
    children,
    isAdmin = false,
}: {
    children: React.ReactNode;
    isAdmin?: boolean;
}) {
    const theme = useTheme();
    const pathname = usePathname();
    const menuItems = isAdmin ? adminMenu : customerMenu;

    return (
        <>
            <CssBaseline />
            <Box
                sx={{
                    display: "flex",
                    height: "100vh",
                    overflow: "hidden",
                    bgcolor: theme.palette.background.default,
                }}
            >
                {/* Sidebar */}
                <Drawer
                    variant="permanent"
                    sx={{
                        width: 240,
                        flexShrink: 0,
                        [`& .MuiDrawer-paper`]: {
                            width: 240,
                            boxSizing: "border-box",
                            backgroundColor: theme.palette.background.paper,
                            borderRight: "1px solid",
                            borderColor: theme.palette.divider,
                        },
                    }}
                >
                    <Box sx={{ p: 3 }}>
                        <Typography variant="h6" fontWeight={700}>
                            SoftDoc AI
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {isAdmin ? "Admin Portal" : "Customer Portal"}
                        </Typography>
                    </Box>

                    <List>
                        {menuItems.map((item) => (
                            <ListItemButton
                                key={item.path}
                                component={Link}
                                href={item.path}
                                selected={pathname === item.path}
                                sx={{
                                    mb: 1,
                                    borderRadius: 2,
                                    "&.Mui-selected": {
                                        backgroundColor: theme.palette.primary.main,
                                        color: theme.palette.primary.contrastText,
                                        "&:hover": {
                                            backgroundColor: theme.palette.primary.dark,
                                        },
                                    },
                                }}
                            >
                                <ListItemText primary={item.label} />
                            </ListItemButton>
                        ))}
                    </List>
                </Drawer>

                {/* Main Content */}
                <Box sx={{ flexGrow: 1, display: "flex", flexDirection: "column" }}>
                    {/* ✅ Shared Topbar for both Admin & User */}
                    <Topbar />

                    <Box
                        component="main"
                        sx={{
                            flexGrow: 1,
                            overflowY: "auto",
                            px: 3,
                            py: 2,
                            backgroundColor: theme.palette.background.default,
                        }}
                    >
                        {children}
                    </Box>
                </Box>
            </Box>
        </>
    );
}
