"use client";

import { Drawer, List, ListItemButton, ListItemText, Box, Typography } from "@mui/material";
import Link from "next/link";
import { usePathname } from "next/navigation";

const navItems = [
    { label: "Dashboard", path: "/user/dashboard" },
    { label: "Data Extraction", path: "/user/data-extraction" },
    { label: "OCR Settings", path: "/user/ocr-settings" },
    { label: "Policies", path: "/user/policies" },
];

export default function Sidebar() {
    const pathname = usePathname();

    return (
        <Drawer
            variant="permanent"
            sx={{
                width: 240,
                flexShrink: 0,
                [`& .MuiDrawer-paper`]: {
                    width: 240,
                    boxSizing: "border-box",
                    backgroundColor: (theme) => theme.palette.background.paper,
                    borderRight: "1px solid",
                    borderColor: (theme) => theme.palette.divider,
                },
            }}
        >
            <Box sx={{ p: 3 }}>
                <Typography variant="h6" fontWeight={700}>
                    SoftDoc AI
                </Typography>
            </Box>
            <List>
                {navItems.map((item) => (
                    <ListItemButton
                        key={item.path}
                        component={Link}
                        href={item.path}
                        selected={pathname === item.path}
                        sx={{
                            mb: 1,
                            borderRadius: 2,
                            "&.Mui-selected": {
                                backgroundColor: (theme) => theme.palette.primary.main,
                                color: (theme) => theme.palette.primary.contrastText,
                            },
                        }}
                    >
                        <ListItemText primary={item.label} />
                    </ListItemButton>
                ))}
            </List>
        </Drawer>
    );
}
