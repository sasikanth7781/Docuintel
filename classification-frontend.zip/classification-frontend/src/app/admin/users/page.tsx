"use client";
import React from "react";
import { Container, Typography } from "@mui/material";
import UsersList from "./UserTable";

export default function AdminUsersPage() {
  return (
    <Container maxWidth="xl" sx={{ py: 3 }}>
      <Typography
        variant="h4"
        fontWeight={700}
        textAlign="center"
        mb={3}
        sx={{
          background: (theme) =>
            `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        User Management
      </Typography>

      <UsersList />
    </Container>
  );
}
