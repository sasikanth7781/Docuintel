"use client";
import React, { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Box, Typography, Paper, Stack } from "@mui/material";
import axios from "axios";

type UserDetail = {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    last_login: string | null;
    user_type: string;
    is_active: boolean;
};

export default function UserDashboard({ params }: { params: { id: string } }) {
    const [user, setUser] = useState<UserDetail | null>(null);

    useEffect(() => {
        axios
            .get(`/api/admin/users/${params.id}/`)
            .then((r) => setUser(r.data))
            .catch(console.error);
    }, [params.id]);

    return (
        <AppLayout isAdmin>
            <Box>
                <Typography variant="h5" fontWeight={700} mb={3}>
                    User Dashboard
                </Typography>

                {/* Use Stack instead of Grid */}
                <Stack
                    direction={{ xs: "column", md: "row" }}
                    spacing={2}
                    sx={{ mb: 3 }}
                >
                    <Paper sx={{ flex: 1, p: 2 }}>
                        <Typography variant="subtitle2" color="text.secondary">
                            Profile
                        </Typography>
                        <Typography variant="h6">
                            {user ? `${user.first_name} ${user.last_name}` : "Loading..."}
                        </Typography>
                        <Typography color="text.secondary">{user?.email}</Typography>
                        <Typography>Type: {user?.user_type}</Typography>
                        <Typography>Status: {user?.is_active ? "Active" : "Inactive"}</Typography>
                        <Typography>Last Login: {user?.last_login || "—"}</Typography>
                    </Paper>

                    <Paper sx={{ flex: 1, p: 2 }}>
                        <Typography variant="subtitle2" color="text.secondary">
                            Usage
                        </Typography>
                        <Typography color="text.secondary">
                            Documents processed, storage used, recent activity — integrate APIs to populate here.
                        </Typography>
                    </Paper>
                </Stack>

                <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle2" color="text.secondary">
                        Recent Activity
                    </Typography>
                    {/* Add logs or table here later */}
                </Paper>
            </Box>
        </AppLayout>
    );
}
