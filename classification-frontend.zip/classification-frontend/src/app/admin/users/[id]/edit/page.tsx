"use client";
import React, { useState, useEffect } from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    MenuItem,
    Stack,
    Typography,
    useTheme,
} from "@mui/material";
import { LoadingButton } from "@mui/lab";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPutApiWithData } from "@/api/api";
import { useSnackbar } from "../../../../../components/snackbar";
import { useRouter, useParams } from "next/navigation";

const EditUserPage = () => {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();
    const { id } = useParams();

    const [open, setOpen] = useState(true);
    const [loading, setLoading] = useState(false);
    const [userData, setUserData] = useState<any>(null);

    const roles = [
        { label: "Admin", value: "admin" },
        { label: "Customer", value: "customer" },
    ];

    // ✅ Load user data from localStorage (listing page stored this)
    useEffect(() => {
        const data = localStorage.getItem("editUser");
        if (data) {
            setUserData(JSON.parse(data));
        } else {
            enqueueSnackbar("User data not found. Redirecting...", { variant: "warning" });
            router.push("/admin/users");
        }
    }, [enqueueSnackbar, router]);

    const handleClose = () => {
        setOpen(false);
        router.push("/admin/users");
    };

    const formik = useFormik({
        enableReinitialize: true,
        initialValues: {
            firstName: userData?.first_name || "",
            lastName: userData?.last_name || "",
            email: userData?.email || "",
            company: userData?.company_name || "",
            role: userData?.role || "",
            isActive: userData?.is_active ?? true,
        },
        validationSchema: Yup.object({
            firstName: Yup.string().required("First name is required"),
            lastName: Yup.string().required("Last name is required"),
            role: Yup.string().required("Role is required"),
        }),
        onSubmit: async (values) => {
            const payload = {
                first_name: values.firstName,
                last_name: values.lastName,
                role: values.role,
                is_active: values.isActive,
            };

            try {
                setLoading(true);
                const userId = Array.isArray(id) ? id[0] : id;

                if (!userId) {
                    enqueueSnackbar("Invalid user ID", { variant: "error" });
                    return;
                }

                // ✅ POST to your update endpoint
                callPutApiWithData(
                    "admin",
                    'users',
                    `${userId}`,
                    payload,
                    (res: any) => {
                        enqueueSnackbar(res.message || "User updated successfully", {
                            variant: "success",
                        });
                        localStorage.removeItem("editUser");
                        handleClose();
                    },
                    (err: any) => {
                        enqueueSnackbar(
                            err?.response?.data?.error || "Failed to update user",
                            { variant: "error" }
                        );
                    }
                );
            } catch {
                enqueueSnackbar("Unexpected error occurred", { variant: "error" });
            } finally {
                setLoading(false);
            }
        },
    });

    if (!userData) return null;

    // ✅ Helper to ensure helperText is always string
    const getHelperText = (field: keyof typeof formik.values) =>
        formik.touched[field] && typeof formik.errors[field] === "string"
            ? formik.errors[field]
            : "";

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            fullWidth
            maxWidth="sm"
            slotProps={{
                paper: {
                    sx: {
                        borderRadius: 3,
                        p: 2,
                        backgroundColor: "rgba(255,255,255,0.9)",
                        backdropFilter: "blur(8px)",
                    },
                },
            }}
        >
            {/* ✅ Title */}
            <DialogTitle>
                <Typography
                    component="div"
                    variant="h5"
                    fontWeight={700}
                    textAlign="center"
                    sx={{
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                    }}
                >
                    Edit User Details
                </Typography>
            </DialogTitle>

            {/* ✅ Form Content */}
            <DialogContent dividers>
                <form onSubmit={formik.handleSubmit}>
                    <Stack spacing={3}>
                        <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                            <TextField
                                label="First Name"
                                name="firstName"
                                fullWidth
                                value={formik.values.firstName}
                                onChange={formik.handleChange}
                                error={formik.touched.firstName && Boolean(formik.errors.firstName)}
                                helperText={getHelperText("firstName")}
                            />
                            <TextField
                                label="Last Name"
                                name="lastName"
                                fullWidth
                                value={formik.values.lastName}
                                onChange={formik.handleChange}
                                error={formik.touched.lastName && Boolean(formik.errors.lastName)}
                                helperText={getHelperText("lastName")}
                            />
                        </Stack>

                        <TextField
                            label="Email"
                            name="email"
                            fullWidth
                            disabled
                            value={formik.values.email}
                        />

                        <TextField
                            label="Company"
                            name="company"
                            fullWidth
                            disabled
                            value={formik.values.company}
                        />

                        <TextField
                            select
                            label="Role"
                            name="role"
                            fullWidth
                            value={formik.values.role}
                            onChange={formik.handleChange}
                            error={formik.touched.role && Boolean(formik.errors.role)}
                            helperText={getHelperText("role")}
                        >
                            {roles.map((r) => (
                                <MenuItem key={r.value} value={r.value}>
                                    {r.label}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Stack>
                </form>
            </DialogContent>

            {/* ✅ Submit Button */}
            <DialogActions>
                <LoadingButton
                    onClick={formik.submitForm}
                    loading={loading}
                    variant="contained"
                    fullWidth
                    sx={{
                        py: 1.5,
                        fontSize: 16,
                        fontWeight: 700,
                        borderRadius: 2,
                        textTransform: "none",
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        "&:hover": { transform: "scale(1.02)" },
                    }}
                >
                    Update User
                </LoadingButton>
            </DialogActions>
        </Dialog>
    );
};

export default EditUserPage;
