"use client";

import React, { useState } from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    MenuItem,
    Stack,
    Typography,
    useTheme,
} from "@mui/material";
import { LoadingButton } from "@mui/lab";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPostApiWithData } from "@/api/api";
import { useRouter } from "next/navigation";
import { useSnackbar } from "@/components/snackbar";

const AddUserPage = () => {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();

    const [open, setOpen] = useState(true);
    const [loading, setLoading] = useState(false);

    const roles = [
        { label: "Admin", value: "admin" },
        { label: "Customer", value: "customer" },
    ];

    const handleClose = () => {
        setOpen(false);
        router.push("/admin/users");
    };

    const formik = useFormik({
        initialValues: {
            firstName: "",
            lastName: "",
            company: "",
            role: "",
            email: "",
        },
        validationSchema: Yup.object({
            firstName: Yup.string().required("First name is required"),
            lastName: Yup.string().required("Last name is required"),
            company: Yup.string().required("Company name is required"),
            role: Yup.string().required("Role is required"),
            email: Yup.string().email("Invalid email").required("Email is required"),
        }),
        onSubmit: async (values) => {
            const payload = {
                email: values.email,
                first_name: values.firstName,
                last_name: values.lastName,
                company_name: values.company,
                role: values.role,
            };

            try {
                setLoading(true);
                callPostApiWithData(
                    "admin",
                    "users/create",
                    payload,
                    (res: any) => {
                        enqueueSnackbar(res?.message || "User created successfully", {
                            variant: "success",
                        });
                        handleClose();
                    },
                    (err: any) => {
                        enqueueSnackbar(
                            err?.response?.data?.error || "Failed to create user",
                            { variant: "error" }
                        );
                    }
                );
            } catch {
                enqueueSnackbar("Unexpected error occurred", { variant: "error" });
            } finally {
                setLoading(false);
            }
        },
    });

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            fullWidth
            maxWidth="sm"
            slotProps={{
                paper: {
                    sx: {
                        borderRadius: 3,
                        p: 2,
                        backgroundColor: "rgba(255,255,255,0.85)",
                        backdropFilter: "blur(8px)",
                    },
                },
            }}
        >
            {/* ✅ Fixed: Avoid <h5> inside <h2> by making Typography a <div> */}
            <DialogTitle>
                <Typography
                    component="div"
                    variant="h5"
                    fontWeight={700}
                    textAlign="center"
                    sx={{
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                    }}
                >
                    Add New User
                </Typography>
            </DialogTitle>

            <DialogContent dividers>
                <form onSubmit={formik.handleSubmit}>
                    <Stack spacing={3}>
                        <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                            <TextField
                                label="First Name"
                                name="firstName"
                                fullWidth
                                value={formik.values.firstName}
                                onChange={formik.handleChange}
                                error={
                                    formik.touched.firstName &&
                                    Boolean(formik.errors.firstName)
                                }
                                helperText={
                                    formik.touched.firstName &&
                                        typeof formik.errors.firstName === "string"
                                        ? formik.errors.firstName
                                        : ""
                                }
                            />

                            <TextField
                                label="Last Name"
                                name="lastName"
                                fullWidth
                                value={formik.values.lastName}
                                onChange={formik.handleChange}
                                error={
                                    formik.touched.lastName &&
                                    Boolean(formik.errors.lastName)
                                }
                                helperText={
                                    formik.touched.lastName &&
                                        typeof formik.errors.lastName === "string"
                                        ? formik.errors.lastName
                                        : ""
                                }
                            />
                        </Stack>

                        <TextField
                            label="Company Name"
                            name="company"
                            fullWidth
                            value={formik.values.company}
                            onChange={formik.handleChange}
                            error={
                                formik.touched.company &&
                                Boolean(formik.errors.company)
                            }
                            helperText={
                                formik.touched.company &&
                                    typeof formik.errors.company === "string"
                                    ? formik.errors.company
                                    : ""
                            }
                        />

                        <TextField
                            select
                            label="Role"
                            name="role"
                            fullWidth
                            value={formik.values.role}
                            onChange={formik.handleChange}
                            error={formik.touched.role && Boolean(formik.errors.role)}
                            helperText={
                                formik.touched.role &&
                                    typeof formik.errors.role === "string"
                                    ? formik.errors.role
                                    : ""
                            }
                        >
                            {roles.map((r) => (
                                <MenuItem key={r.value} value={r.value}>
                                    {r.label}
                                </MenuItem>
                            ))}
                        </TextField>

                        <TextField
                            label="Email Address"
                            name="email"
                            type="email"
                            fullWidth
                            value={formik.values.email}
                            onChange={formik.handleChange}
                            error={formik.touched.email && Boolean(formik.errors.email)}
                            helperText={
                                formik.touched.email &&
                                    typeof formik.errors.email === "string"
                                    ? formik.errors.email
                                    : ""
                            }
                        />
                    </Stack>
                </form>
            </DialogContent>

            <DialogActions>
                <LoadingButton
                    onClick={formik.submitForm}
                    loading={loading}
                    variant="contained"
                    fullWidth
                    sx={{
                        py: 1.5,
                        fontSize: 16,
                        fontWeight: 700,
                        borderRadius: 2,
                        textTransform: "none",
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        "&:hover": { transform: "scale(1.02)" },
                    }}
                >
                    Create User
                </LoadingButton>
            </DialogActions>
        </Dialog>
    );
};

export default AddUserPage;
