"use client";

import React, { useEffect, useState, useMemo, useCallback } from "react";
import {
    Box,
    Button,
    TextField,
    Select,
    MenuItem,
    InputLabel,
    FormControl,
    IconButton,
    Tooltip,
    Paper,
    useTheme,
    Chip,
} from "@mui/material";
import {
    DataGrid,
    GridColDef,
    GridPaginationModel,
} from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import VisibilityIcon from "@mui/icons-material/Visibility";
import { callDeleteApiWithData, callGetApiWithData } from "@/api/api";
import { useSnackbar } from "../../../components/snackbar";
import { useRouter } from "next/navigation";

interface UserRow {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    is_active: boolean;
    company_name: string | null;
    role: string | null;
}

interface PaginatedResponse<T> {
    count: number;
    next: string | null;
    previous: string | null;
    results: T[];
}

const UsersList: React.FC = () => {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();

    const [rows, setRows] = useState<UserRow[]>([]);
    const [page, setPage] = useState<number>(0);
    const [pageSize, setPageSize] = useState<number>(10);
    const [rowCount, setRowCount] = useState<number>(0);
    const [loading, setLoading] = useState<boolean>(false);
    const [search, setSearch] = useState<string>("");
    const [role, setRole] = useState<string>("all");
    const [status, setStatus] = useState<string>("all");

    /** 🔹 Fetch users */
    const fetchUsers = useCallback(async (): Promise<void> => {
        setLoading(true);
        try {
            const params = {
                page: page + 1,
                page_size: pageSize,
                q: search || undefined,
                role: role !== "all" ? role : undefined,
                status: status !== "all" ? status : undefined,
            };

            callGetApiWithData(
                "admin",
                "users",
                params,
                (res: any) => {
                    const data = res as PaginatedResponse<UserRow>;
                    setRows(data.results || []);
                    setRowCount(data.count || 0);
                },
                (err: any) => {
                    enqueueSnackbar(err?.response?.data?.error || "Failed to load users", {
                        variant: "error",
                    });
                    setRows([]);
                    setRowCount(0);
                }
            );
        } catch {
            enqueueSnackbar("Something went wrong while fetching users.", {
                variant: "error",
            });
        } finally {
            setLoading(false);
        }
    }, [page, pageSize, search, role, status, enqueueSnackbar]);

    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    /** ✏️ Edit handler */
    const handleEdit = (user: UserRow): void => {
        localStorage.setItem("editUser", JSON.stringify(user));
        router.push(`/admin/users/${user.id}/edit`);
    };

    /** 🔄 Toggle Active/Inactive */
    const handleToggleStatus = async (user: UserRow): Promise<void> => {
        try {
            callDeleteApiWithData(
                "admin",
                "users",
                `${user.id}/delete/`,
                (res: any) => {
                    enqueueSnackbar(res?.message || "User status updated successfully", {
                        variant: "success",
                    });
                    fetchUsers();
                },
                (err: any) => {
                    enqueueSnackbar(
                        err?.response?.data?.message || "Failed to toggle user status",
                        { variant: "error" }
                    );
                }
            );
        } catch {
            enqueueSnackbar("Unexpected error occurred while toggling status", {
                variant: "error",
            });
        }
    };

    /** 🧱 Columns */
    const columns: GridColDef<UserRow>[] = useMemo(
        () => [
            { field: "first_name", headerName: "First Name", flex: 1, minWidth: 150 },
            { field: "last_name", headerName: "Last Name", flex: 1, minWidth: 150 },
            { field: "email", headerName: "Email", flex: 1.3, minWidth: 220 },
            {
                field: "role",
                headerName: "Role",
                flex: 0.8,
                minWidth: 120,
                renderCell: (params) => {
                    const roleLabel =
                        params.row.role?.toLowerCase() === "customer"
                            ? "Customer"
                            : "Admin";
                    const gradient =
                        roleLabel === "Customer"
                            ? `linear-gradient(90deg, ${theme.palette.secondary.main}, ${theme.palette.primary.light})`
                            : `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.light})`;

                    return (
                        <Chip
                            label={roleLabel}
                            size="small"
                            sx={{
                                fontWeight: 600,
                                color: "#fff",
                                background: gradient,
                            }}
                        />
                    );
                },
            },
            {
                field: "is_active",
                headerName: "Status",
                flex: 0.8,
                minWidth: 130,
                renderCell: (params) => {
                    const label = params.row.is_active ? "Active" : "Inactive";
                    const gradient = params.row.is_active
                        ? `linear-gradient(90deg, ${theme.palette.success.main}, ${theme.palette.primary.light})`
                        : `linear-gradient(90deg, ${theme.palette.grey[500]}, ${theme.palette.grey[400]})`;

                    return (
                        <Chip
                            label={label}
                            size="small"
                            sx={{
                                fontWeight: 600,
                                color: "#fff",
                                background: gradient,
                            }}
                        />
                    );
                },
            },
            {
                field: "company_name",
                headerName: "Company",
                flex: 1,
                minWidth: 180,
                valueGetter: (value, row) => row.company_name || "—",
            },
            {
                field: "actions",
                headerName: "Actions",
                flex: 0.8,
                minWidth: 160,
                sortable: false,
                renderCell: (params) => (
                    <Box sx={{ display: "flex", gap: 1 }}>
                        <Tooltip title="View Dashboard">
                            <IconButton
                                size="small"
                                href={`/admin/users/${params.row.id}`}
                                sx={{ color: theme.palette.info.main }}
                            >
                                <VisibilityIcon fontSize="small" />
                            </IconButton>
                        </Tooltip>

                        <Tooltip title="Edit User">
                            <IconButton
                                size="small"
                                onClick={() => handleEdit(params.row)}
                                sx={{ color: theme.palette.primary.main }}
                            >
                                <EditIcon fontSize="small" />
                            </IconButton>
                        </Tooltip>

                        <Tooltip
                            title={params.row.is_active ? "Deactivate User" : "Activate User"}
                        >
                            <IconButton
                                size="small"
                                onClick={() => handleToggleStatus(params.row)}
                                sx={{
                                    color: params.row.is_active
                                        ? theme.palette.warning.main
                                        : theme.palette.success.main,
                                }}
                            >
                                {params.row.is_active ? (
                                    <ToggleOffIcon fontSize="small" />
                                ) : (
                                    <ToggleOnIcon fontSize="small" />
                                )}
                            </IconButton>
                        </Tooltip>
                    </Box>
                ),
            },
        ],
        [theme]
    );

    /** 🔹 Pagination handler */
    const handlePaginationChange = (model: GridPaginationModel): void => {
        setPage(model.page);
        setPageSize(model.pageSize);
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                background: theme.palette.background.default,
                p: { xs: 2, sm: 3 },
                borderRadius: 3,
                width: "100%",
            }}
        >
            <Paper
                elevation={6}
                sx={{
                    width: "100%",
                    borderRadius: 3,
                    p: { xs: 2, sm: 3 },
                    backgroundColor: "rgba(255,255,255,0.98)",
                    boxShadow: "0px 4px 18px rgba(0,0,0,0.06)",
                    overflowX: "hidden",
                }}
            >
                {/* Filters */}
                <Box
                    sx={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 2,
                        mb: 3,
                        alignItems: "center",
                        justifyContent: "space-between",
                    }}
                >
                    <TextField
                        placeholder="Search by name or email"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        size="small"
                        sx={{ flex: 1, minWidth: 220 }}
                    />
                    <FormControl size="small" sx={{ width: 140 }}>
                        <InputLabel>Role</InputLabel>
                        <Select
                            label="Role"
                            value={role}
                            onChange={(e) => setRole(e.target.value)}
                        >
                            <MenuItem value="all">All</MenuItem>
                            <MenuItem value="customer">Customer</MenuItem>
                            <MenuItem value="admin">Admin</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl size="small" sx={{ width: 140 }}>
                        <InputLabel>Status</InputLabel>
                        <Select
                            label="Status"
                            value={status}
                            onChange={(e) => setStatus(e.target.value)}
                        >
                            <MenuItem value="all">All</MenuItem>
                            <MenuItem value="active">Active</MenuItem>
                            <MenuItem value="inactive">Inactive</MenuItem>
                        </Select>
                    </FormControl>
                    <Button
                        variant="contained"
                        href="/admin/users/new"
                        sx={{
                            px: 4,
                            py: 1.4,
                            borderRadius: 3,
                            textTransform: "none",
                            fontWeight: 700,
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            "&:hover": { transform: "scale(1.03)" },
                        }}
                    >
                        + Add User
                    </Button>
                </Box>

                {/* DataGrid */}
                <Box
                    sx={{
                        height: 560,
                        "& .MuiDataGrid-columnHeaders": {
                            background: `linear-gradient(90deg, ${theme.palette.primary.light}, ${theme.palette.secondary.light})`,
                            color: "#fff",
                            fontWeight: 700,
                            borderBottom: "none",
                        },
                        "& .MuiDataGrid-cell": {
                            borderBottom: "none",
                        },
                        "& .MuiDataGrid-footerContainer": {
                            backgroundColor: theme.palette.grey[50],
                        },
                        "& .MuiDataGrid-virtualScroller": {
                            overflowX: "hidden",
                        },
                    }}
                >
                    <DataGrid<UserRow>
                        rows={rows}
                        columns={columns}
                        paginationModel={{ page, pageSize }}
                        onPaginationModelChange={handlePaginationChange}
                        paginationMode="server"
                        rowCount={rowCount}
                        loading={loading}
                        disableRowSelectionOnClick
                        getRowId={(r) => r.id}
                        pageSizeOptions={[10, 25, 50]}
                    />
                </Box>
            </Paper>
        </Box>
    );
};

export default UsersList;
