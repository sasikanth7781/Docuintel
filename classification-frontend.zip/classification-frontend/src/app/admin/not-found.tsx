export default function NotFound() {
  return <h2 style={{padding:24}}>Admin page not found</h2>;
}
