"use client";
import { useEffect, useState } from "react";
import { Box, CircularProgress } from "@mui/material";
import MetricsCards from "./components/MetricsCards";
import ProcessingSummaryChart from "./components/ProcessingSummaryChart";
import OCRAccuracyPie from "./components/OCRAccuracyPie";
import CustomersBarChart from "./components/CustomersBarChart";
import RecentActivitiesTable from "./components/RecentActivitiesTable";
import NotificationsList from "./components/NotificationsList";
import {
  getOverview,
  getProcessingSummary,
  getCustomers,
  getNotifications,
} from "./services/dashboardApi";
import {
  MOCK_OVERVIEW,
  MOCK_PROCESSING,
  MOCK_CUSTOMERS,
  MOCK_NOTIFICATIONS,
} from "./mock";
import { useSnackbar } from "@/components/snackbar";

export default function DashboardPage() {
  const [overview, setOverview] = useState<any | null>(null);
  const [processing, setProcessing] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    (async () => {
      try {
        const [ov, ps, cs, nt] = await Promise.all([
          getOverview(),
          getProcessingSummary(new Date().getFullYear(), new Date().getMonth() + 1),
          getCustomers(new Date().getFullYear()),
          getNotifications(),
        ]);

        setOverview(ov);
        setProcessing(ps.days ?? []);
        setCustomers(cs.monthly_registrations ?? []);
        setNotifications(nt.notifications ?? []);
      } catch (err) {
        console.warn("Dashboard API failed, using mock data:", err);
        enqueueSnackbar("Using mock data (API unavailable)", { variant: "warning" });
        setOverview(MOCK_OVERVIEW);
        setProcessing(MOCK_PROCESSING.days);
        setCustomers(MOCK_CUSTOMERS.monthly_registrations);
        setNotifications(MOCK_NOTIFICATIONS.notifications);
      } finally {
        setLoading(false);
      }
    })();
  }, [enqueueSnackbar]);

  if (loading)
    return (
      <Box sx={{ display: "flex", justifyContent: "center", mt: 10 }}>
        <CircularProgress />
      </Box>
    );

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 2, p: 2 }}>
      {/* Top cards */}
      <MetricsCards cards={overview.cards} />

      {/* Processing summary + OCR accuracy */}
      <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 2 }}>
        <Box sx={{ flex: 2 }}>
          <ProcessingSummaryChart data={processing} />
        </Box>
        <Box sx={{ flex: 1 }}>
          <OCRAccuracyPie data={overview.ocr_accuracy_distribution} />
        </Box>
      </Box>

      {/* Customers + Notifications */}
      <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 2 }}>
        <Box sx={{ flex: 2 }}>
          <CustomersBarChart data={customers} />
        </Box>
        <Box sx={{ flex: 1 }}>
          <NotificationsList notifications={notifications} />
        </Box>
      </Box>

      {/* Recent activities */}
      <RecentActivitiesTable activities={overview.recent_activities} />
    </Box>
  );
}
