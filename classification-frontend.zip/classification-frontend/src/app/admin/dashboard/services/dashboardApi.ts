// app/dashboard/services/dashboardApi.ts
import {
    callGetApiWithData,
    callPostApiWithData,
    callDeleteApiWithData,
    callPutApiWithData,
    callPatchApiWithData,
} from "@/api/api"; // update path if your api.tsx lives elsewhere

type Callback = (res: any) => void;

const wrapGet = (endpoint: string, params = {}) =>
    new Promise<any>((resolve, reject) => {
        callGetApiWithData(
            endpoint,
            null,
            params,
            (res: any) => resolve(res),
            (err: any) => reject(err)
        );
    });

export const getOverview = (opts = {}) => wrapGet("/api/dashboard/overview/", opts);
export const getProcessingSummary = (year: number, month: number) =>
    wrapGet("/api/dashboard/processing-summary/", { year, month });
export const getCustomers = (year: number) => wrapGet("/api/dashboard/customers/", { year });
export const getNotifications = () => wrapGet("/api/dashboard/notifications/");
