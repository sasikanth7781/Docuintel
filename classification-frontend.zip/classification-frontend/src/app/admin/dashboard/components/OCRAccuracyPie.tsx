"use client";
import { Card, CardContent, Typography } from "@mui/material";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const COLORS = ["#4caf50", "#2196f3", "#ff9800", "#f44336"];

export default function OCRAccuracyPie({ data }: any) {
    const chartData = [
        { name: "90–100%", value: data["90_to_100"] },
        { name: "80–90%", value: data["80_to_90"] },
        { name: "70–80%", value: data["70_to_80"] },
        { name: "Below 70%", value: data["below_70"] },
    ];

    return (
        <Card variant="outlined">
            <CardContent>
                <Typography variant="h6" mb={2}>OCR Accuracy Distribution</Typography>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie data={chartData} dataKey="value" nameKey="name" outerRadius={100}>
                            {chartData.map((_, index) => (
                                <Cell key={index} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}
