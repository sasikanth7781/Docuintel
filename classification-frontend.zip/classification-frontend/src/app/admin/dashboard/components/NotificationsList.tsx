"use client";
import { Card, CardContent, Typography, List, ListItem, ListItemText } from "@mui/material";

export default function NotificationsList({ notifications }: { notifications: string[] }) {
    return (
        <Card variant="outlined">
            <CardContent>
                <Typography variant="h6" mb={2}>Notifications / Alerts</Typography>
                <List dense>
                    {notifications.map((n, i) => (
                        <ListItem key={i} divider>
                            <ListItemText primary={n} />
                        </ListItem>
                    ))}
                </List>
            </CardContent>
        </Card>
    );
}
