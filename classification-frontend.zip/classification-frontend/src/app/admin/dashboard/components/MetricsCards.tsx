"use client";
import { Box, Card, CardContent, Typography, Stack } from "@mui/material";

type Props = {
    cards: {
        total_customers: number;
        total_documents_processed: number;
        failed_documents: number;
        accurate_documents_percent: number;
        active_ocrs_count: number;
    };
};

export default function MetricsCards({ cards }: Props) {
    const items = [
        { label: "Total Customers", value: cards.total_customers },
        { label: "Total Documents Processed", value: cards.total_documents_processed },
        { label: "Failed/Error Documents", value: cards.failed_documents },
        { label: "Accurate Documents (%)", value: `${cards.accurate_documents_percent}%` },
        { label: "Active OCR’s Count", value: cards.active_ocrs_count },
    ];

    return (
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 2, justifyContent: "space-between" }}>
            {items.map((it) => (
                <Box
                    key={it.label}
                    sx={{
                        flex: { xs: "1 1 100%", sm: "1 1 calc(50% - 16px)", md: "1 1 calc(20% - 16px)" },
                    }}
                >
                    <Card variant="outlined" sx={{ bgcolor: "background.paper", height: "100%" }}>
                        <CardContent>
                            <Stack spacing={0.5}>
                                <Typography variant="subtitle2" color="text.secondary">{it.label}</Typography>
                                <Typography variant="h5" fontWeight={700}>{it.value}</Typography>
                            </Stack>
                        </CardContent>
                    </Card>
                </Box>
            ))}
        </Box>
    );
}
