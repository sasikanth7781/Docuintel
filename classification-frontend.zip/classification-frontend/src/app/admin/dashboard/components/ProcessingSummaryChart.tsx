"use client";
import { useState } from "react";
import { Box, Card, CardContent, Typography, MenuItem, Select, Stack } from "@mui/material";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { MOCK_PROCESSING } from "../mock";

export default function ProcessingSummaryChart({ data = MOCK_PROCESSING.days }) {
    const [year, setYear] = useState(2025);
    const [month, setMonth] = useState(10);

    return (
        <Card variant="outlined">
            <CardContent>
                <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="h6">Processing Summary</Typography>
                    <Stack direction="row" spacing={1}>
                        <Select size="small" value={year} onChange={(e) => setYear(Number(e.target.value))}>
                            {[2024, 2025].map((y) => (
                                <MenuItem key={y} value={y}>{y}</MenuItem>
                            ))}
                        </Select>
                        <Select size="small" value={month} onChange={(e) => setMonth(Number(e.target.value))}>
                            {Array.from({ length: 12 }).map((_, i) => (
                                <MenuItem key={i + 1} value={i + 1}>
                                    {new Date(0, i).toLocaleString("default", { month: "short" })}
                                </MenuItem>
                            ))}
                        </Select>
                    </Stack>
                </Stack>

                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" label={{ value: "Day of Month", position: "insideBottom", offset: -5 }} />
                        <YAxis label={{ value: "Documents", angle: -90, position: "insideLeft" }} />
                        <Tooltip />
                        <Line type="monotone" dataKey="completed" stroke="#1976d2" name="Completed" />
                        <Line type="monotone" dataKey="failed" stroke="#d32f2f" name="Failed" />
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}
