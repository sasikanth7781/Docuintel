"use client";
import { Card, CardContent, Typography, Table, TableHead, TableRow, TableCell, TableBody } from "@mui/material";

export default function RecentActivitiesTable({ activities }: any) {
    return (
        <Card variant="outlined">
            <CardContent>
                <Typography variant="h6" mb={2}>Recent Activities / Logs</Typography>
                <Table size="small">
                    <TableHead>
                        <TableRow>
                            <TableCell>Date</TableCell>
                            <TableCell>Action</TableCell>
                            <TableCell>User</TableCell>
                            <TableCell>Module</TableCell>
                            <TableCell>Status</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {activities.map((a: any, i: number) => (
                            <TableRow key={i}>
                                <TableCell>{a.date}</TableCell>
                                <TableCell>{a.action}</TableCell>
                                <TableCell>{a.user}</TableCell>
                                <TableCell>{a.module}</TableCell>
                                <TableCell>{a.status}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}
