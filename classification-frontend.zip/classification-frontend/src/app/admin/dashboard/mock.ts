// app/dashboard/mock.ts
export const MOCK_OVERVIEW = {
    cards: {
        total_customers: 3567,
        total_documents_processed: 195504,
        failed_documents: 6723,
        accurate_documents_percent: 94.5,
        active_ocrs_count: 6,
    },
    ocr_accuracy_distribution: {
        "90_to_100": 1200,
        "80_to_90": 340,
        "70_to_80": 150,
        "below_70": 50,
    },

    recent_activities: [
        { date: "2025-10-29", action: "Deleted User", user: "Admin", module: "User Mgmt", status: "Success" },
        { date: "2025-10-29", action: "Created OCR Task", user: "Admin", module: "OCR", status: "Success" },
    ],
};

export const MOCK_PROCESSING = {
    year: 2025,
    month: 10,
    days: [
        { day: 1, completed: 22, failed: 4 },
        { day: 2, completed: 28, failed: 6 },
        { day: 3, completed: 34, failed: 3 },
        { day: 4, completed: 45, failed: 5 },
        // add more days as needed
    ],
};

export const MOCK_CUSTOMERS = {
    year: 2025,
    monthly_registrations: [
        { month: "Jan", count: 150 }, { month: "Feb", count: 175 }, { month: "Mar", count: 200 },
        { month: "Apr", count: 225 }, { month: "May", count: 250 }, { month: "Jun", count: 275 },
        { month: "Jul", count: 260 }, { month: "Aug", count: 280 }, { month: "Sep", count: 300 },
        { month: "Oct", count: 310 }, { month: "Nov", count: 330 }, { month: "Dec", count: 350 },
    ],
};

export const MOCK_NOTIFICATIONS = {
    notifications: [
        "OCR Engine Textract API limit reached",
        "3 new customers registered today",
        "2 errors in Error_Folder today",
    ],
};
