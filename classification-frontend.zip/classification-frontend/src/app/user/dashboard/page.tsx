"use client";

import {
    Box,
    Typography,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
} from "@mui/material";
import { useState } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
    Legend,
} from "recharts";

const yearOptions = [2025, 2026, 2027];
const monthOptions = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
];

const yearlyData = [
    { month: "Jan", pages: 400 },
    { month: "Feb", pages: 500 },
    { month: "Mar", pages: 600 },
    { month: "Apr", pages: 700 },
    { month: "May", pages: 800 },
    { month: "Jun", pages: 900 },
    { month: "Jul", pages: 1000 },
    { month: "Aug", pages: 1100 },
    { month: "Sep", pages: 1200 },
    { month: "Oct", pages: 1300 },
    { month: "Nov", pages: 1400 },
    { month: "Dec", pages: 1500 },
];

const pieData = [
    { name: "Paddle OCR", value: 45 },
    { name: "Google Document AI", value: 30 },
    { name: "AWS Textract", value: 15 },
    { name: "Pytesseract", value: 10 },
];

const pieColors = ["#4A90E2", "#9B6EF3", "#F5A623", "#7ED321"];

const generateMonthlyData = (days: number) =>
    Array.from({ length: days }, (_, i) => ({
        day: `${i + 1}`,
        pages: Math.floor(Math.random() * 200) + 100,
    }));

export default function DashboardPage() {
    const [selectedYear, setSelectedYear] = useState(2025);
    const [selectedMonth, setSelectedMonth] = useState("October");

    const daysInMonth =
        selectedMonth === "February"
            ? 28
            : ["April", "June", "September", "November"].includes(selectedMonth)
                ? 30
                : 31;

    const monthlyData = generateMonthlyData(daysInMonth);

    return (
        <Box sx={{ px: 4, py: 6 }}>
            <Typography variant="h4" fontWeight={700} gutterBottom>
                Dashboard
            </Typography>

            {/* Yearly and Pie Charts */}
            <Stack
                direction={{ xs: "column", md: "row" }}
                spacing={6}
                sx={{ mb: 6 }}
            >
                {/* Yearly Bar Chart */}
                <Box sx={{ flex: 1 }}>
                    <Stack spacing={2}>
                        <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="h6" fontWeight={600}>
                                Pages Extracted in a Year
                            </Typography>
                            <FormControl size="small" sx={{ minWidth: 120 }}>
                                <InputLabel>Year</InputLabel>
                                <Select
                                    value={selectedYear}
                                    label="Year"
                                    onChange={(e) => setSelectedYear(Number(e.target.value))}
                                >
                                    {yearOptions.map((year) => (
                                        <MenuItem key={year} value={year}>
                                            {year}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Box>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={yearlyData}>
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Bar dataKey="pages" fill="#4A90E2" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </Stack>
                </Box>

                {/* Pie Chart */}
                <Box sx={{ flex: 1 }}>
                    <Stack spacing={2}>
                        <Typography variant="h6" fontWeight={600}>
                            Pages Extracted by OCR
                        </Typography>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={pieData}
                                    dataKey="value"
                                    nameKey="name"
                                    cx="50%"
                                    cy="45%" // 👈 slightly higher to make room for legend
                                    outerRadius={100} // 👈 slightly smaller for spacing
                                    label={({ name, x, y }) => (
                                        <text
                                            x={x}
                                            y={y + 18} // 👈 push labels downward
                                            textAnchor="middle"
                                            fill="#333"
                                            fontSize={12}
                                        >
                                            {name}
                                        </text>
                                    )}
                                >
                                    {pieData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                                    ))}
                                </Pie>
                                <Legend
                                    layout="horizontal"
                                    verticalAlign="bottom"
                                    align="center"
                                    wrapperStyle={{ marginTop: 24 }} />
                            </PieChart>
                        </ResponsiveContainer>
                    </Stack>
                </Box>
            </Stack>

            {/* Monthly Bar Chart */}
            <Stack spacing={2}>
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="h6" fontWeight={600}>
                        Pages Extracted in Current Month
                    </Typography>
                    <Stack direction="row" spacing={2}>
                        <FormControl size="small" sx={{ minWidth: 120 }}>
                            <InputLabel>Year</InputLabel>
                            <Select
                                value={selectedYear}
                                label="Year"
                                onChange={(e) => setSelectedYear(Number(e.target.value))}
                            >
                                {yearOptions.map((year) => (
                                    <MenuItem key={year} value={year}>
                                        {year}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl size="small" sx={{ minWidth: 140 }}>
                            <InputLabel>Month</InputLabel>
                            <Select
                                value={selectedMonth}
                                label="Month"
                                onChange={(e) => setSelectedMonth(e.target.value)}
                            >
                                {monthOptions.map((month) => (
                                    <MenuItem key={month} value={month}>
                                        {month}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Stack>
                </Box>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={monthlyData}>
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="pages" fill="#9B6EF3" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </Stack>
        </Box>
    );
}
