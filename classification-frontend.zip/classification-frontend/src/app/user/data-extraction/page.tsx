"use client";
import React, { useState, useRef } from "react";
import {
    Box,
    Typography,
    Button,
    Paper,
    IconButton,
    useTheme,
} from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import JSZip from "jszip";
import { callPostApiWithData } from "@/api/api";

interface FolderStatus {
    id: string;
    path: string;
    files: File[];
    progress: number;
    status: "pending" | "zipping" | "uploading" | "uploaded" | "error";
}

const generateFolderId = (path: string) => path + "-" + Date.now() + Math.random();

const FolderUpload: React.FC = () => {
    const theme = useTheme();
    const [folders, setFolders] = useState<FolderStatus[]>([]);
    const [dragActive, setDragActive] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    /** Handle folder selection (drag or browse) */
    const handleFolderSelect = (filesList: FileList | null) => {
        if (!filesList) return;
        const folderMap: Record<string, File[]> = {};
        Array.from(filesList).forEach((file) => {
            const relativePath = file.webkitRelativePath || file.name;
            const folderPath = relativePath.split("/")[0];
            if (!folderMap[folderPath]) folderMap[folderPath] = [];
            folderMap[folderPath].push(file);
        });
        const newFolders: FolderStatus[] = Object.entries(folderMap).map(([path, files]) => ({
            id: generateFolderId(path),
            path,
            files,
            progress: 0,
            status: "pending",
        }));
        setFolders((prev) => [...prev, ...newFolders]);
    };

    const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setDragActive(true); };
    const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setDragActive(false); };
    const handleDrop = (e: React.DragEvent) => { e.preventDefault(); setDragActive(false); handleFolderSelect(e.dataTransfer.files); };
    const removeFolder = (id: string) => setFolders((prev) => prev.filter((f) => f.id !== id));

    /** Zip and upload all folders using presigned URLs */
    const uploadAllFolders = async () => {
        if (!folders.length) return;

        // Step 1: Ask backend for presigned URLs (one per zip file)
        const payload = { folders: folders.map((f) => ({ relativePath: f.path + ".zip" })) };

        const onSuccess = async (res: any) => {
            const presignedFolders = res?.folders || [];

            for (const folder of folders) {
                const presigned = presignedFolders.find((p: any) => p.relativePath === folder.path + ".zip");
                if (!presigned?.uploadUrl) continue;

                try {
                    setFolders((prev) =>
                        prev.map((f) => f.id === folder.id ? { ...f, status: "zipping", progress: 0 } : f)
                    );

                    // Step 2: Create a ZIP archive of the folder
                    const zip = new JSZip();
                    for (const file of folder.files) {
                        const relativePath = file.webkitRelativePath?.split("/").slice(1).join("/") || file.name;
                        zip.file(relativePath, file);
                    }

                    const zipBlob = await zip.generateAsync({ type: "blob" }, (meta) => {
                        const progress = Math.round(meta.percent);
                        setFolders((prev) =>
                            prev.map((f) => f.id === folder.id ? { ...f, progress } : f)
                        );
                    });

                    // Step 3: Upload the ZIP to AWS S3 presigned URL
                    setFolders((prev) =>
                        prev.map((f) => f.id === folder.id ? { ...f, status: "uploading", progress: 0 } : f)
                    );

                    await axios.put(presigned.uploadUrl, zipBlob, {
                        headers: { "Content-Type": "application/zip" },
                        onUploadProgress: (e) => {
                            const percent = Math.round((e.loaded / (e.total || 1)) * 100);
                            setFolders((prev) =>
                                prev.map((f) => f.id === folder.id ? { ...f, progress: percent } : f)
                            );
                        },
                    });

                    // Step 4: Mark upload done
                    setFolders((prev) =>
                        prev.map((f) => f.id === folder.id ? { ...f, status: "uploaded", progress: 100 } : f)
                    );
                } catch (err) {
                    console.error("Upload failed:", err);
                    setFolders((prev) =>
                        prev.map((f) => f.id === folder.id ? { ...f, status: "error" } : f)
                    );
                }
            }
        };

        const onError = (err: any) => {
            console.error("Presigned URL fetch failed:", err);
            setFolders((prev) => prev.map((f) => ({ ...f, status: "error" })));
        };

        callPostApiWithData("presign-folder-upload", null, payload, onSuccess, onError);
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                minHeight: "88vh",
                p: 3,
                background: theme.palette.background.default,
            }}
        >
            <Typography variant="h4" fontWeight={700} color={theme.palette.primary.main} mb={3} textAlign="center">
                Upload Folders
            </Typography>

            <Paper
                elevation={6}
                sx={{
                    display: "flex",
                    flexDirection: "row",
                    width: "90%",
                    maxWidth: "1300px",
                    borderRadius: 3,
                    overflow: "hidden",
                    p: 3,
                    gap: 3,
                    minHeight: 400,
                }}
            >
                {/* Left Panel (Drag & Drop Area) */}
                <Box
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onClick={() => fileInputRef.current?.click()}
                    sx={{
                        flex: 1.3,
                        p: 4,
                        borderRadius: 3,
                        textAlign: "center",
                        cursor: "pointer",
                        border: `2px dashed ${dragActive ? theme.palette.primary.main : theme.palette.primary.light}`,
                        backgroundColor: dragActive ? "rgba(200,230,255,0.3)" : "rgba(250,250,255,0.6)",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        minHeight: 380,
                        transition: "0.2s ease",
                        "&:hover": {
                            transform: "scale(1.02)",
                            boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
                        },
                    }}
                >
                    <CloudUploadIcon sx={{ fontSize: 75, color: theme.palette.primary.main, mb: 1 }} />
                    <Typography
                        sx={{
                            fontWeight: 700,
                            fontSize: 22,
                            textTransform: "uppercase",
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                        }}
                    >
                        DRAG & DROP OR BROWSE
                    </Typography>
                    <Typography variant="body1" color="text.secondary">
                        Upload multiple folders (auto-zipped)
                    </Typography>
                    <input
                        ref={fileInputRef}
                        type="file"
                        hidden
                        multiple
                        {...({ webkitdirectory: "true", directory: "true" } as any)}
                        onChange={(e) => handleFolderSelect(e.target.files)}
                    />
                </Box>

                {/* Right Panel (Status) */}
                <Box
                    sx={{
                        flex: 0.7,
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: "rgba(250,250,250,0.8)",
                        display: "flex",
                        flexDirection: "column",
                        maxHeight: 380,
                        overflowY: "auto",
                        "&::-webkit-scrollbar": { width: "8px" },
                        "&::-webkit-scrollbar-thumb": {
                            background: theme.palette.primary.main,
                            borderRadius: 4,
                        },
                    }}
                >
                    <Typography
                        variant="h6"
                        fontWeight={700}
                        color={theme.palette.primary.main}
                        mb={2}
                        sx={{
                            position: "relative",
                            fontSize: 20,
                            "&::after": {
                                content: '""',
                                position: "absolute",
                                left: 0,
                                bottom: -3,
                                width: "50%",
                                height: 3,
                                borderRadius: 2,
                                background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            },
                        }}
                    >
                        Selected Folders
                    </Typography>

                    {folders.length === 0 ? (
                        <Typography color="text.secondary" fontSize={16}>No folders selected yet.</Typography>
                    ) : (
                        folders.map((folder) => (
                            <Paper
                                key={folder.id}
                                sx={{
                                    p: 1.4,
                                    mb: 1,
                                    borderRadius: 2,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    backgroundColor:
                                        folder.status === "uploaded"
                                            ? "rgba(76,175,80,0.1)"
                                            : folder.status === "error"
                                                ? "rgba(244,67,54,0.1)"
                                                : folder.status === "uploading"
                                                    ? "rgba(33,150,243,0.08)"
                                                    : "rgba(250,250,250,0.6)",
                                    border: folder.status === "pending" ? `1px solid ${theme.palette.divider}` : "none",
                                }}
                            >
                                <Typography fontWeight={600}>{folder.path}.zip</Typography>
                                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                    {folder.status === "uploaded" && <CheckCircleIcon color="success" />}
                                    {folder.status === "error" && <ErrorOutlineIcon color="error" />}
                                    <IconButton onClick={() => removeFolder(folder.id)} size="small">
                                        <DeleteIcon fontSize="small" />
                                    </IconButton>
                                </Box>
                            </Paper>
                        ))
                    )}
                </Box>
            </Paper>

            {folders.length > 0 && (
                <Button
                    variant="contained"
                    onClick={uploadAllFolders}
                    sx={{
                        mt: 2,
                        px: 6,
                        py: 1.8,
                        borderRadius: 3,
                        fontSize: 17,
                        textTransform: "none",
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        "&:hover": { transform: "scale(1.02)" },
                    }}
                >
                    Upload All Folders
                </Button>
            )}
        </Box>
    );
};

export default FolderUpload;
