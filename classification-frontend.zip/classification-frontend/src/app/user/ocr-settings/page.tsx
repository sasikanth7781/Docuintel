"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
    Box,
    Typography,
    Paper,
    Checkbox,
    Button,
    FormControl,
    InputLabel,
    OutlinedInput,
    useTheme,
} from "@mui/material";
import { useSnackbar } from "@/components/snackbar";
import { callGetApiWithData, callPatchApiWithData } from "@/api/api";

interface OCRService {
    id?: number; // API ID
    key: string;
    label: string;
    enabled: boolean;
    accuracy: number;
}

// Fixed OCR services (always visible)
const ALL_OCR_SERVICES: OCRService[] = [
    { key: "pytesseract", label: "PyTesseract", enabled: false, accuracy: 90 },
    { key: "paddleocr", label: "PaddleOCR", enabled: false, accuracy: 90 },
    { key: "google_doc_ai", label: "Google Document AI", enabled: false, accuracy: 90 },
    { key: "aws_textract", label: "AWS Textract", enabled: false, accuracy: 90 },
];

const OCRSettingsPage: React.FC = () => {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();
    const [services, setServices] = useState<OCRService[]>(ALL_OCR_SERVICES);
    const [apiEnabledOcrs, setApiEnabledOcrs] = useState<OCRService[]>([]);
    const [loading, setLoading] = useState(false);

    /** Fetch OCR settings from API */
    const fetchOCRSettings = useCallback(() => {
        setLoading(true);

        callGetApiWithData(
            "ocr-settings", // GET endpoint
            null,
            {},
            (res: any) => {
                const fetched: OCRService[] = res?.services || [];

                // Merge API response with fixed services
                const merged = ALL_OCR_SERVICES.map((ocr) => {
                    const match = fetched.find((s) => s.key === ocr.key);
                    return match ? { ...ocr, enabled: match.enabled, accuracy: match.accuracy, id: match.id } : ocr;
                });

                setServices(merged);
                // Right panel: only OCRs that are enabled in API
                setApiEnabledOcrs(merged.filter((s) => s.enabled));
                setLoading(false);
            },
            (err: any) => {
                console.error(err);
                enqueueSnackbar("Failed to fetch OCR settings.", { variant: "error" });
                setLoading(false);
            }
        );
    }, [enqueueSnackbar]);

    useEffect(() => {
        fetchOCRSettings();
    }, [fetchOCRSettings]);

    /** Toggle OCR service enabled state locally */
    const toggleOCR = (key: string) => {
        const updated = services.map((ocr) => (ocr.key === key ? { ...ocr, enabled: !ocr.enabled } : ocr));
        setServices(updated);
    };

    /** Change OCR accuracy locally */
    const changeAccuracy = (key: string, value: number) => {
        if (isNaN(value) || value < 0 || value > 100) return;
        const updated = services.map((ocr) => (ocr.key === key ? { ...ocr, accuracy: value } : ocr));
        setServices(updated);
    };

    /** Save OCR settings via PATCH API */
    const handleSave = () => {
        setLoading(true);

        const payload = {
            services: services.map(({ id, key, enabled, accuracy }) => ({ id, key, enabled, accuracy })),
        };

        callPatchApiWithData(
            "ocr-settings",
            null,
            payload,
            (res: any) => {
                enqueueSnackbar(res?.message || "OCR settings updated!", { variant: "success" });
                fetchOCRSettings();
            },
            (err: any) => {
                console.error(err);
                enqueueSnackbar("Failed to update OCR settings.", { variant: "error" });
                setLoading(false);
            }
        );
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                minHeight: "88vh",
                p: 3,
                background: theme.palette.background.default,
            }}
        >
            <Typography
                variant="h4"
                fontWeight={700}
                color={theme.palette.primary.main}
                mb={3}
                textAlign="center"
            >
                OCR Settings
            </Typography>

            <Paper
                elevation={6}
                sx={{
                    display: "flex",
                    flexDirection: "row",
                    width: "90%",
                    maxWidth: 1300,
                    borderRadius: 3,
                    overflow: "hidden",
                    p: 3,
                    gap: 3,
                    minHeight: 400,
                }}
            >
                {/* Left Panel */}
                <Box
                    sx={{
                        flex: 1.3,
                        p: 3,
                        borderRadius: 3,
                        border: `2px dashed ${theme.palette.primary.light}`,
                        backgroundColor: "rgba(250,250,255,0.6)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 2,
                        overflowY: "auto",
                    }}
                >
                    {services.map((ocr) => (
                        <Paper
                            key={ocr.key}
                            sx={{
                                p: 2,
                                mb: 1,
                                borderRadius: 2,
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                background: "linear-gradient(90deg, #f5f7fa, #e0eafc)",
                                "&:hover": {
                                    transform: "scale(1.02)",
                                    boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
                                    background: "linear-gradient(90deg, #dbe6ff, #c0d6ff)",
                                },
                            }}
                        >
                            <Box display="flex" alignItems="center" gap={1.5}>
                                <Checkbox checked={ocr.enabled} onChange={() => toggleOCR(ocr.key)} />
                                <Typography fontWeight={600}>{ocr.label}</Typography>
                            </Box>

                            {ocr.enabled && (
                                <FormControl sx={{ width: 120 }} size="small">
                                    <InputLabel htmlFor={`${ocr.key}-accuracy`}>Accuracy</InputLabel>
                                    <OutlinedInput
                                        id={`${ocr.key}-accuracy`}
                                        type="number"
                                        value={ocr.accuracy ?? ""}
                                        onChange={(e) => changeAccuracy(ocr.key, parseFloat(e.target.value))}
                                        label="Accuracy"
                                        inputProps={{ min: 0, max: 100 }}
                                    />
                                </FormControl>
                            )}
                        </Paper>
                    ))}

                    <Button
                        variant="contained"
                        onClick={handleSave}
                        sx={{
                            mt: 2,
                            px: 6,
                            py: 1.5,
                            borderRadius: 3,
                            fontSize: 16,
                            textTransform: "none",
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            "&:hover": { transform: "scale(1.02)" },
                        }}
                        disabled={loading}
                    >
                        Save Changes
                    </Button>
                </Box>

                {/* Right Panel: Only OCRs with enabled: true from API */}
                <Box
                    sx={{
                        flex: 0.7,
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: "rgba(250,250,250,0.8)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 1,
                        maxHeight: 380,
                        overflowY: "auto",
                    }}
                >
                    <Typography
                        variant="h6"
                        fontWeight={700}
                        color={theme.palette.primary.main}
                        mb={2}
                        sx={{
                            display: "inline", // only under the text
                            fontSize: 20,
                            borderBottom: "3px solid",
                            borderImage: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main}) 1`,
                            borderRadius: "2px",
                        }}
                    >
                        Saved OCRs
                    </Typography>



                    {apiEnabledOcrs.length === 0 ? (
                        <Typography color="text.secondary" fontSize={16}>
                            No OCRs enabled
                        </Typography>
                    ) : (
                        apiEnabledOcrs.map((ocr) => (
                            <Paper
                                key={ocr.key}
                                sx={{
                                    p: 1.4,
                                    mb: 1,
                                    borderRadius: 2,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    backgroundColor: "rgba(76,175,80,0.08)",
                                    transition: "all 0.3s ease",
                                    "&:hover": {
                                        transform: "scale(1.02)",
                                        boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
                                        backgroundColor: "rgba(76,175,80,0.12)",
                                    },
                                }}
                            >
                                <Typography fontWeight={600}>{ocr.label}</Typography>
                                {ocr.accuracy !== undefined && <Typography>{ocr.accuracy}%</Typography>}
                            </Paper>
                        ))
                    )}
                </Box>
            </Paper>
        </Box>
    );
};

export default OCRSettingsPage;
