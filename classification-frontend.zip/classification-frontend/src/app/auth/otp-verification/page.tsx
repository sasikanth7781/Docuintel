"use client";

import {
    Box,
    Button,
    Stack,
    TextField,
    Typography,
    useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPostApiWithData } from "@/api/api";
import SecureStorage from "react-secure-storage";
import { useRouter } from "next/navigation";
import { useSnackbar } from "../../../components/snackbar";
import { setTokens } from "@/utils/tokenHelper";

const OtpSchema = Yup.object().shape({
    otp: Yup.string()
        .required("OTP is required")
        .matches(/^\d{6}$/, "OTP must be exactly 6 digits"),
});

export default function OtpVerification() {
    const router = useRouter();
    const { enqueueSnackbar } = useSnackbar();
    const theme = useTheme();

    const formik = useFormik({
        initialValues: {
            otp: "",
        },
        validationSchema: OtpSchema,
        onSubmit: (values) => {
            try {
                const requestData = {
                    email: SecureStorage.getItem("email"),
                    otp: values.otp,
                };

                const onSuccess = (res: any) => {
                    enqueueSnackbar(res.message, { variant: "success" });
                    //SecureStorage.removeItem("email");
                    setTokens(res.access, res.refresh);
                    router.push("/user/dashboard");
                };

                const onError = (err: any) => {
                    enqueueSnackbar(err.response.data.error, { variant: "error" });
                };

                callPostApiWithData("customer", "verify-otp", requestData, onSuccess, onError);
            } catch {
                enqueueSnackbar("Error while verifying OTP.", { variant: "error" });
            }
        },
    });

    const handleResend = () => {
        try {
            const email = SecureStorage.getItem("email");
            callPostApiWithData(
                "customer",
                "resend-otp",
                { email },
                (res: any) => enqueueSnackbar(res.message, { variant: "success" }),
                () => enqueueSnackbar("Error while resending OTP.", { variant: "error" })
            );
        } catch {
            enqueueSnackbar("Error while resending OTP.", { variant: "error" });
        }
    };

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                backgroundColor: "background.default",
                overflow: "hidden",
            }}
        >
            {/* Left: Form */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    px: { xs: 3, md: 8 },
                }}
            >
                <Box sx={{ width: "100%", maxWidth: 400 }}>
                    <Stack spacing={5}>
                        {/* Heading */}
                        <Box>
                            <Typography
                                variant="h4"
                                fontWeight={700}
                                sx={{
                                    background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    letterSpacing: "-0.4px",
                                    lineHeight: 1.2,
                                    fontSize: { xs: "1.8rem", md: "2.2rem" },
                                }}
                            >
                                Enter OTP
                            </Typography>
                            <Typography
                                variant="subtitle1"
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    fontWeight: 400,
                                    fontSize: "1rem",
                                    lineHeight: 1.6,
                                }}
                            >
                                We’ve sent a 6-digit code to your email. Enter it below to complete your registration.
                            </Typography>
                        </Box>

                        {/* Form */}
                        <form onSubmit={formik.handleSubmit}>
                            <Stack spacing={2.5}>
                                <TextField
                                    fullWidth
                                    label="OTP Code"
                                    name="otp"
                                    type="tel"
                                    inputMode="numeric"
                                    value={formik.values.otp}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                    error={formik.touched.otp && Boolean(formik.errors.otp)}
                                    helperText={formik.touched.otp && formik.errors.otp}
                                />

                                <Button
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 600,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                        boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                                    }}
                                >
                                    Continue
                                </Button>

                                <Button
                                    variant="outlined"
                                    color="info"
                                    fullWidth
                                    onClick={handleResend}
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 500,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                    }}
                                >
                                    Resend Code
                                </Button>
                            </Stack>
                        </form>
                    </Stack>
                </Box>
            </Box>

            {/* Right: Illustration */}
            <Box
                sx={{
                    flex: 1,
                    display: { xs: "none", md: "flex" },
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "background.neutral",
                    px: 4,
                }}
            >
                <img
                    src="/undraw_artificial-intelligence_43qa.svg"
                    alt="AI Document Verification Illustration"
                    style={{ maxHeight: "80vh", width: "auto" }}
                />
            </Box>
        </Box>
    );
}
