"use client";

import {
  Box,
  Button,
  Divider,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { Formik, Form, useFormik } from "formik";
import * as Yup from "yup";
import OutlinedPassword from "@/components/password";
import AppConstant from "@/app/constant/AppConstant";
import { useSnackbar } from "@/components/snackbar";
import { callPostApiWithData } from "@/api/api";
import SecureStorage from "react-secure-storage";
import { setTokens } from "@/utils/tokenHelper";

// Validation schema
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;
const validationSchema = Yup.object().shape({
  email: Yup.string().matches(emailRegex, AppConstant.VALID_EMAIL_ADDRESS).required(AppConstant.EMAIL_IS_REQUIRED),
  password: Yup.string()
    .required(AppConstant.PASSWORD_REQUIRED)
    .matches(
      passwordRules,
      AppConstant.VALID_PASSWORD
    ),
});

export default function LoginPage() {
  const router = useRouter();
  const { enqueueSnackbar } = useSnackbar();


  const formik = useFormik({
    initialValues: {
      email: "",
      password: ""
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        const requestData = {
          username: values.email,
          password: values.password,
          role: "admin"
        };

        const onSuccess = (res: any) => {
          enqueueSnackbar("Login successful.", { variant: "success" });
          setTokens(res.access, res.refresh);
          setTimeout(() => {
            if (res.role === "admin") {
              router.push("/admin/dashboard");
            } else {
              router.push("/user/dashboard");
            }
          }, 1200);
        };


        const onError = (err: any) => {
          enqueueSnackbar(err.response.data.error, { variant: "error" });
        };
        callPostApiWithData("customer", "login", requestData, onSuccess, onError);

      }
      catch {
        enqueueSnackbar("Error while logging in with user. Please try again.", {
          variant: "error",
        });
      }
    }
  });

  const onClickGoogleLogin = () => {
    try {
      const rootUrl = "https://accounts.google.com/o/oauth2/v2/auth";

      const params = new URLSearchParams({
        client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!,
        redirect_uri: "http://localhost:3000/auth/callback",
        response_type: "code",
        scope: "openid email profile",
        access_type: "offline",
        prompt: "consent",
      });

      window.location.href = `${rootUrl}?${params.toString()}`;
    }
    catch {
      enqueueSnackbar("Error while logging in with Google. Please try again.", {
        variant: "error",
      });
    }
  }

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        overflow: "hidden",
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        backgroundColor: "background.default",
      }}
    >
      {/* Left: Login Form */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          px: { xs: 3, md: 8 },
        }}
      >
        <Box sx={{ width: "100%", maxWidth: 440 }}>
          <Stack spacing={5}>
            {/* Heading */}
            <Box>
              <Typography
                variant="h2"
                fontWeight={800}
                sx={{
                  background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  letterSpacing: "-0.5px",
                  lineHeight: 1.1,
                  fontSize: { xs: "2.2rem", md: "2.8rem" },
                }}
              >
                SoftDoc AI
              </Typography>
              <Typography
                variant="subtitle1"
                color="text.secondary"
                sx={{
                  mt: 1,
                  fontWeight: 400,
                  fontSize: "1.05rem",
                  lineHeight: 1.6,
                }}
              >
                Smart document automation for modern teams. Sign in to get started.
              </Typography>
            </Box>

            {/* Google Sign-In First */}
            <Button
              variant="outlined"
              fullWidth
              color="info"
              startIcon={
                <img
                  src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                  alt="Google logo"
                  style={{ width: 20, height: 20 }}
                />
              }
              sx={{
                textTransform: "none",
                fontWeight: 600,
                py: 1.5,
                borderRadius: 2,
                fontSize: "1rem",
              }}
              onClick={onClickGoogleLogin}
            >
              Sign in with Google
            </Button>

            <Divider sx={{ my: 1 }}>or</Divider>

            <form onSubmit={formik.handleSubmit}>
              <Stack spacing={2}>
                <TextField
                  label="Email"
                  name="email"
                  type="email"
                  fullWidth
                  value={formik.values.email}
                  onChange={formik.handleChange}
                  error={formik.touched.email && Boolean(formik.errors.email)}
                  helperText={formik.touched.email && formik.errors.email}
                />

                <OutlinedPassword
                  name="password"
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  error={formik.touched.password && Boolean(formik.errors.password)}
                  helperText={formik.touched.password && formik.errors.password}
                />
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  fullWidth
                  size="large"
                  sx={{
                    textTransform: "none",
                    fontWeight: 600,
                    py: 1.5,
                    borderRadius: 2,
                    fontSize: "1rem",
                    boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                  }}
                >
                  Login with Email
                </Button>
                <Stack direction="row" justifyContent="space-between">
                  <Button variant="text" onClick={() => router.push("/auth/forgot-password")}>
                    Forgot Password?
                  </Button>
                  <Button variant="text" onClick={() => router.push("/auth/register")}>
                    Register
                  </Button>
                </Stack>
              </Stack>
            </form>
          </Stack>
        </Box>
      </Box>

      {/* Right: Illustration */}
      <Box
        sx={{
          flex: 1,
          display: { xs: "none", md: "flex" },
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "background.neutral",
          px: 4,
          overflow: "hidden",
        }}
      >
        <img
          src="/undraw_artificial-intelligence_43qa.svg"
          alt="AI Document Processing Illustration"
          style={{ maxWidth: "80%", height: "auto" }}
        />
      </Box>
    </Box>
  );
}
