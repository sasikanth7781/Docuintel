"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Box, CircularProgress, Typography, Stack } from "@mui/material";
import SecureStorage from "react-secure-storage";
import { setTokens } from "@/utils/tokenHelper";

export default function CallbackPage() {
    const router = useRouter();

    useEffect(() => {
        const handleGoogleCallback = async () => {
            try {
                const urlParams = new URLSearchParams(window.location.search);
                const code = urlParams.get("code");

                if (!code) {
                    console.error("No authorization code found in URL");
                    router.replace("/auth/login");
                    return;
                }

                // ✅ Always use absolute URL (NEXT_PUBLIC_API_REDIRECT_URL must be full URL)
                const response = await fetch(process.env.NEXT_PUBLIC_API_REDIRECT_URL as string, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ code }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();

                if (data?.user && data?.jwt_access && data?.jwt_refresh) {
                    const user = data.user;


                    SecureStorage.setItem("id", user.id);
                    SecureStorage.setItem("email", user.email);
                    SecureStorage.setItem("name", user.name);
                    SecureStorage.setItem("given_name", user.given_name);
                    SecureStorage.setItem("family_name", user.family_name);
                    SecureStorage.setItem("picture", user.picture);
                    setTokens(data.jwt_access, data.jwt_refresh);
                    console.log("✅ Google login success:", user);

                    // ✅ Ensure token is written before redirect
                    setTimeout(() => {
                        router.replace("/user/dashboard");
                    }, 300);
                } else {
                    console.error("Invalid response data:", data);
                    //router.replace("/auth/login");
                }
            } catch (err) {
                console.error("Google callback error:", err);
                //router.replace("/auth/login");
            }
        };

        handleGoogleCallback();
    }, [router]);

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100vw",
                backgroundColor: "background.default",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                px: 4,
            }}
        >
            <Stack spacing={3} alignItems="center">
                <CircularProgress color="primary" size={48} />
                <Typography
                    variant="h6"
                    fontWeight={500}
                    color="text.secondary"
                    sx={{ textAlign: "center", maxWidth: 360 }}
                >
                    Logging you in securely with Google. Please wait while we verify your account…
                </Typography>
            </Stack>
        </Box>
    );
}
