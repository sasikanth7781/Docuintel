"use client";

import SecureStorage from "react-secure-storage";
import { jwtDecode } from "jwt-decode";

const isBrowser = typeof window !== "undefined";

export const getAccessToken = (): string | null => {
    if (!isBrowser) return null;
    return SecureStorage.getItem("accessToken") as string | null;
};

export const getRefreshToken = (): string | null => {
    if (!isBrowser) return null;
    return SecureStorage.getItem("refreshToken") as string | null;
};

export const setTokens = (access: string, refresh: string) => {
    SecureStorage.setItem("accessToken", access);
    SecureStorage.setItem("refreshToken", refresh);
};

export const clearTokens = () => {
    SecureStorage.removeItem("accessToken");
    SecureStorage.removeItem("refreshToken");
};

export const isTokenExpired = (token: string): boolean => {
    try {
        const decoded: any = jwtDecode(token);
        console.log(!decoded?.exp,"token exipred");
        if (!decoded?.exp) return true;
        return decoded.exp * 1000 < Date.now();
    } catch {
        return true;
    }
};
