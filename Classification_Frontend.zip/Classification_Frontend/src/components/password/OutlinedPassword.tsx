import {
    FormControl,
    IconButton,
    InputAdornment,
    InputLabel,
    OutlinedInput,
    OutlinedInputProps,
    FormHelperText,
} from "@mui/material";
import { useState } from "react";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

type OutlinedPasswordProps = Omit<OutlinedInputProps, "type"> & {
    label?: string;
    error?: boolean;
    helperText?: React.ReactNode;
};

export default function OutlinedPassword({
    label = "Password",
    error,
    helperText,
    ...props
}: OutlinedPasswordProps) {
    const [showPassword, setShowPassword] = useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    return (
        <FormControl
            variant="outlined"
            error={error}
            fullWidth
        >
            <InputLabel htmlFor={props.id || "outlined-adornment-password"}>
                {label}
            </InputLabel>
            <OutlinedInput
                {...props}
                id={props.id || "outlined-adornment-password"}
                type={showPassword ? "text" : "password"}
                endAdornment={
                    <InputAdornment position="end">
                        <IconButton
                            aria-label={
                                showPassword ? "hide the password" : "display the password"
                            }
                            onClick={handleClickShowPassword}
                            edge="end"
                        >
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                    </InputAdornment>
                }
                label={label}
            />
            {helperText && <FormHelperText >{helperText}</FormHelperText>}
        </FormControl>
    );
}
