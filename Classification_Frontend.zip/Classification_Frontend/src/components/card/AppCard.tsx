"use client";

import { Container, Paper, Typography, PaperProps } from "@mui/material";
import { ReactNode } from "react";

interface AppCardProps extends PaperProps {
    title?: string;
    children: ReactNode;
    align?: "left" | "center";
    maxWidth?: "xs" | "sm" | "md" | "lg" | "xl";
}

export default function AppCard({
    title,
    children,
    align = "center",
    maxWidth = "sm",
    sx,
    ...rest
}: AppCardProps) {
    return (
        <Container maxWidth={maxWidth}>
            <Paper
                elevation={3}
                sx={{
                    p: { xs: 2, sm: 4 },
                    mt: { xs: 4, sm: 8 },
                    borderRadius: (theme) => (theme.shape.borderRadius as number) * 2,
                    textAlign: align,
                    boxShadow: (theme) => theme.shadows[4],
                    ...sx,
                }}
                {...rest}
            >
                {title && (
                    <Typography
                        variant="h5"
                        component="h2"
                        gutterBottom
                        sx={{ fontWeight: 600, mb: 2, textAlign: align }}
                    >
                        {title}
                    </Typography>
                )}
                {children}
            </Paper>
        </Container>
    );
}
