"use client";

import { Button } from "@mui/material";
import { useRouter } from "next/navigation";
import SecureStorage from "react-secure-storage";

export default function LogoutButton() {
    const router = useRouter();

    const handleLogout = async () => {
        try {
            await fetch(`${process.env.NEXT_PUBLIC_API_LOGOUT_URL}`, {
                method: "POST",
                credentials: "include",
                headers: {
                    "Content-Type": "application/json",
                },
            });

            SecureStorage.clear();
            localStorage.clear();

            router.push("/auth/login");
        } catch (err) {
            console.error("Logout failed:", err);
        }
    };

    return (
        <Button
            variant="outlined"
            color="error"
            onClick={handleLogout}
            sx={{
                textTransform: "none",
                fontWeight: 600,
                position: "fixed",
                top: 16,
                right: 24,
                zIndex: 1000,
            }}
        >
            Logout
        </Button>
    );
}
