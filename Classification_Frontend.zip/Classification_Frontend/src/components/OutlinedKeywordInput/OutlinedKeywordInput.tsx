import { useState } from "react";
import { TextField, Button, Stack } from "@mui/material";

type Props = {
    label: string;
    onAddKeyword: (kw: string) => void;
    value?: string;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

export default function OutlinedKeywordInput({ label, onAddKeyword, value, onChange }: Props) {
    const [inputValue, setInputValue] = useState("");

    const handleAdd = () => {
        const kw = value !== undefined ? value.trim() : inputValue.trim();
        if (!kw) return;
        onAddKeyword(kw);
        if (value === undefined) setInputValue("");
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (onChange) onChange(e);
        else setInputValue(e.target.value);
    };

    return (
        <Stack direction="row" spacing={1}>
            <TextField
                label={label}
                value={value !== undefined ? value : inputValue}
                onChange={handleChange}
                fullWidth
            />
            <Button variant="contained" onClick={handleAdd}>
                Add
            </Button>
        </Stack>
    );
}
