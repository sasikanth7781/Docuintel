"use client";

import {
    Box,
    Avatar,
    Typography,
    IconButton,
    Menu,
    MenuItem,
    Divider,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { useEffect, useState } from "react";
import PasswordDialog from "./PasswordDialog";
import SecureStorage from "react-secure-storage";
import { callPostApiWithData } from "@/api/api";
import { useSnackbar } from "@/components/snackbar";
import { useRouter } from "next/navigation";
import { getEmail, getFullName } from "@/utils/tokenHelper";

export default function Topbar({ openSidebar, isMobile }: any) {

    const [name, setName] = useState("User");
    const [email, setEmail] = useState("user@example.com");

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [openPassword, setOpenPassword] = useState(false);

    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();
    const refreshToken = SecureStorage.getItem("refreshToken") as string;

    useEffect(() => {
        setName(getFullName() || "User");
        setEmail(getEmail() || "user@example.com");
    }, []);

    const handleLogout = () => {
        callPostApiWithData(
            "logout",
            null,
            { refresh_token: refreshToken },
            () => {
                enqueueSnackbar("Logged out successfully.", { variant: "success" });
                SecureStorage.clear();
                router.push("/auth/login");
            },
            () => {
                SecureStorage.clear();
                router.push("/auth/login");
            }
        );
    };

    return (
        <Box
            sx={{
                height: 64,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                px: 2,
                backgroundColor: (theme) => theme.palette.background.paper,
                borderBottom: "1px solid",
                borderColor: (theme) => theme.palette.divider,
                position: "sticky",
                top: 0,
                zIndex: 1200,
            }}
        >

            {/* MOBILE MENU */}
            {isMobile && (
                <IconButton onClick={openSidebar}>
                    <MenuIcon />
                </IconButton>
            )}

            <Box sx={{ flexGrow: 1 }} />

            <IconButton onClick={(e) => setAnchorEl(e.currentTarget)}>
                <Avatar
                    sx={{
                        bgcolor: (theme) => theme.palette.primary.main,
                        width: 42,
                        height: 42,
                        fontWeight: 700,
                    }}
                >
                    {(name?.[0] || "U").toUpperCase()}
                </Avatar>
            </IconButton>

            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={() => setAnchorEl(null)}
            >
                <Box px={2} py={1}>
                    <Typography fontWeight={700}>{name}</Typography>
                    <Typography variant="body2">{email}</Typography>
                </Box>

                <Divider />

                <MenuItem onClick={() => setOpenPassword(true)}>
                    Reset Password
                </MenuItem>

                <MenuItem onClick={handleLogout}>
                    Logout
                </MenuItem>
            </Menu>

            <PasswordDialog
                open={openPassword}
                onClose={() => setOpenPassword(false)}
            />
        </Box>
    );
}