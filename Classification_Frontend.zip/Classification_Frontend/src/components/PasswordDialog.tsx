"use client";

import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    Button,
    Stack,
    Typography,
} from "@mui/material";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import AppConstant from "@/app/constant/AppConstant";
import { callPostApiWithData } from "@/api/api";
import { useSnackbar } from "@/components/snackbar";
import OutlinedPassword from "@/components/password";
import { useState } from "react";
import CircularProgress from "@mui/material/CircularProgress";

interface PasswordDialogProps {
    open: boolean;
    onClose: () => void;
}

const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;

export default function PasswordDialog({ open, onClose }: PasswordDialogProps) {
    const { enqueueSnackbar } = useSnackbar();
    const [loading, setLoading] = useState(false);

    const initialValues = {
        oldPassword: "",
        newPassword: "",
        confirmPassword: "",
    };

    const validationSchema = Yup.object({
        oldPassword: Yup.string().required("Old password is required"),
        newPassword: Yup.string()
            .required(AppConstant.PASSWORD_REQUIRED)
            .matches(
                passwordRules,
                AppConstant.VALID_PASSWORD
            ),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref("newPassword")], "Passwords must match")
            .required("Confirm password is required"),
    });

    const handleSubmit = async (
        values: typeof initialValues,
        resetForm: () => void
    ) => {
        if (loading) return; // ✅ prevent double click

        setLoading(true);

        try {
            const onSuccess = (res: any) => {
                enqueueSnackbar("Password updated successfully.", { variant: "success" });
                resetForm();
                onClose();
                setLoading(false); // ✅ reset
            };

            const onError = (err: any) => {
                console.error(err);
                enqueueSnackbar(err?.response?.data?.error || "Something went wrong", {
                    variant: "error",
                });
                setLoading(false); // ✅ reset
            };

            await callPostApiWithData(
                "customer",
                "change-password",
                {
                    old_password: values.oldPassword,
                    new_password: values.newPassword,
                },
                onSuccess,
                onError
            );
        } catch (error) {
            console.error("Unexpected error:", error);
            enqueueSnackbar("Error while resetting password.", { variant: "error" });
            setLoading(false);
        }
    };


    return (
        <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
            <DialogTitle>
                {/* Use component="div" to avoid nested heading */}
                <Typography component="div" variant="h6" fontWeight={700}>
                    Reset Password
                </Typography>
            </DialogTitle>

            <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={(values, { resetForm }) => handleSubmit(values, resetForm)}
            >
                {({ handleChange, values, touched, errors }) => (
                    <Form>
                        <DialogContent>
                            <Stack spacing={3} mt={1}>
                                <OutlinedPassword
                                    name="oldPassword"
                                    label="Old Password"

                                    value={values.oldPassword}
                                    onChange={handleChange}
                                    fullWidth
                                    size="medium"
                                    error={touched.oldPassword && Boolean(errors.oldPassword)}
                                    helperText={touched.oldPassword && errors.oldPassword}
                                />

                                <OutlinedPassword
                                    name="newPassword"
                                    label="New Password"

                                    value={values.newPassword}
                                    onChange={handleChange}
                                    fullWidth
                                    size="medium"
                                    error={touched.newPassword && Boolean(errors.newPassword)}
                                    helperText={touched.newPassword && errors.newPassword}
                                />

                                <OutlinedPassword
                                    name="confirmPassword"
                                    label="Confirm New Password"
                                    value={values.confirmPassword}
                                    onChange={handleChange}
                                    fullWidth
                                    size="medium"
                                    error={touched.confirmPassword && Boolean(errors.confirmPassword)}
                                    helperText={touched.confirmPassword && errors.confirmPassword}
                                />

                            </Stack>
                        </DialogContent>

                        <DialogActions sx={{ justifyContent: "space-between", px: 3, pb: 2 }}>
                            <Button
                                variant="outlined"
                                onClick={onClose}
                                disabled={loading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                variant="contained"
                                disabled={loading}
                                sx={{
                                    px: 4,
                                    py: 1.5,
                                    fontWeight: 600,
                                    textTransform: "none",
                                    borderRadius: 2,
                                    minWidth: 140,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    gap: 1,
                                    background: (theme) =>
                                        `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 100%)`,
                                    "&:hover": {
                                        background: (theme) =>
                                            `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
                                    },
                                }}
                            >
                                {loading ? (
                                    <>
                                        <CircularProgress size={20} color="inherit" />
                                        Updating...
                                    </>
                                ) : (
                                    "Update"
                                )}
                            </Button>
                        </DialogActions>
                    </Form>
                )}
            </Formik>
        </Dialog>
    );
}
