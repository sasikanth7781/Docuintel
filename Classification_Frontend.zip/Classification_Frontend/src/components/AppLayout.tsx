"use client";

import React from "react";
import {
    Box,
    CssBaseline,
    Drawer,
    List,
    ListItemButton,
    ListItemText,
    Typography,
    IconButton,
    useTheme,
    useMediaQuery,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { usePathname } from "next/navigation";
import Link from "next/link";
import Topbar from "@/components/Topbar";

const drawerWidth = 240;

const customerMenu = [
    { label: "Data Extraction", path: "/user/data-extraction" },
    { label: "OCR Settings", path: "/user/ocr-settings" },
    { label: "Policies", path: "/user/policies" },
];


export default function AppLayout({
    children,
    isAdmin = false,
}: {
    children: React.ReactNode;
    isAdmin?: boolean;
}) {

    const theme = useTheme();
    const pathname = usePathname();
    const isMobile = useMediaQuery(theme.breakpoints.down("md"));

    const [mobileOpen, setMobileOpen] = React.useState(false);
    const [loading, setLoading] = React.useState(false);

    React.useEffect(() => {
        setLoading(false);
        setMobileOpen(false);
    }, [pathname]);

    const drawerContent = (
        <>
            <Box sx={{ p: 3 }}>
                <Typography variant="h6" fontWeight={700}>
                    SoftDoc AI
                </Typography>

                <Typography variant="body2" color="text.secondary">
                    {isAdmin ? "Admin Portal" : "Customer Portal"}
                </Typography>
            </Box>

            <List>
                {customerMenu.map((item) => (
                    <ListItemButton
                        key={item.path}
                        component={Link}
                        href={item.path}
                        selected={pathname === item.path}
                        onClick={() => {
                            if (pathname !== item.path) {
                                setLoading(true);
                            }
                        }}
                        sx={{
                            mb: 1,
                            borderRadius: 2,
                            "&.Mui-selected": {
                                backgroundColor: theme.palette.primary.main,
                                color: theme.palette.primary.contrastText,
                                "&:hover": {
                                    backgroundColor: theme.palette.primary.dark,
                                },
                            },
                        }}
                    >
                        <ListItemText primary={item.label} />
                    </ListItemButton>
                ))}
            </List>
        </>
    );

    return (
        <>
            <CssBaseline />

            <Box
                sx={{
                    display: "flex",
                    height: "100vh",
                    overflow: "hidden",
                    bgcolor: theme.palette.background.default,

                    "@keyframes loadingBar": {
                        "0%": { left: "-30%" },
                        "50%": { left: "50%" },
                        "100%": { left: "100%" },
                    },
                }}
            >

                {/* MOBILE DRAWER */}
                {isMobile && (
                    <Drawer
                        variant="temporary"
                        open={mobileOpen}
                        onClose={() => setMobileOpen(false)}
                        ModalProps={{ keepMounted: true }}
                        sx={{
                            "& .MuiDrawer-paper": {
                                width: drawerWidth,
                                boxSizing: "border-box",
                            },
                        }}
                    >
                        {drawerContent}
                    </Drawer>
                )}

                {/* DESKTOP DRAWER */}
                {!isMobile && (
                    <Drawer
                        variant="permanent"
                        sx={{
                            width: drawerWidth,
                            flexShrink: 0,
                            [`& .MuiDrawer-paper`]: {
                                width: drawerWidth,
                                boxSizing: "border-box",
                                backgroundColor: theme.palette.background.paper,
                                borderRight: "1px solid",
                                borderColor: theme.palette.divider,
                            },
                        }}
                    >
                        {drawerContent}
                    </Drawer>
                )}

                {/* MAIN CONTENT */}
                <Box
                    sx={{
                        flexGrow: 1,
                        display: "flex",
                        flexDirection: "column",
                        width: "100%",
                    }}
                >

                    <Topbar
                        openSidebar={() => setMobileOpen(true)}
                        isMobile={isMobile}
                    />

                    {loading && (
                        <Box
                            sx={{
                                height: 3,
                                width: "100%",
                                position: "relative",
                                overflow: "hidden",
                            }}
                        >
                            <Box
                                sx={{
                                    height: "100%",
                                    width: "30%",
                                    position: "absolute",
                                    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                                    animation: "loadingBar 1.2s infinite",
                                }}
                            />
                        </Box>
                    )}

                    <Box
                        component="main"
                        sx={{
                            flexGrow: 1,
                            overflowY: "auto",
                            px: { xs: 2, md: 3 },
                            py: 2,
                            backgroundColor: theme.palette.background.default,
                        }}
                    >
                        {children}
                    </Box>
                </Box>
            </Box>
        </>
    );
}