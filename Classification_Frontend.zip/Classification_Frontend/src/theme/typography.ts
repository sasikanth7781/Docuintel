import { Barlow, Inter } from "next/font/google";

// ----------------------------------------------------------------------

export function remToPx(value: string) {
  return Math.round(parseFloat(value) * 16);
}

export function pxToRem(value: number) {
  return `${value / 16}rem`;
}

export function responsiveFontSizes({
  sm,
  md,
  lg,
}: {
  sm: number;
  md: number;
  lg: number;
}) {
  return {
    "@media (min-width:600px)": {
      fontSize: pxToRem(sm),
    },
    "@media (min-width:900px)": {
      fontSize: pxToRem(md),
    },
    "@media (min-width:1200px)": {
      fontSize: pxToRem(lg),
    },
  };
}

declare module "@mui/material/styles" {
  interface TypographyVariants {
    fontSecondaryFamily: React.CSSProperties["fontFamily"];
    fontWeightSemiBold: React.CSSProperties["fontWeight"];
  }
}

// Fonts
export const primaryFont = Inter({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

export const secondaryFont = Barlow({
  weight: ["500", "600", "700", "800"],
  subsets: ["latin"],
  display: "swap",
});

// ----------------------------------------------------------------------

export const typography = {
  fontFamily: primaryFont.style.fontFamily,
  fontSecondaryFamily: secondaryFont.style.fontFamily,
  fontWeightRegular: 400,
  fontWeightMedium: 500,
  fontWeightSemiBold: 600,
  fontWeightBold: 700,

  // Headlines
  h1: {
    fontWeight: 800,
    fontFamily: secondaryFont.style.fontFamily,
    lineHeight: 1.15,
    fontSize: pxToRem(44),
    ...responsiveFontSizes({ sm: 52, md: 60, lg: 68 }),
  },
  h2: {
    fontWeight: 700,
    fontFamily: secondaryFont.style.fontFamily,
    lineHeight: 1.2,
    fontSize: pxToRem(36),
    ...responsiveFontSizes({ sm: 40, md: 44, lg: 48 }),
  },
  h3: {
    fontWeight: 700,
    fontFamily: primaryFont.style.fontFamily,
    lineHeight: 1.3,
    fontSize: pxToRem(28),
    ...responsiveFontSizes({ sm: 30, md: 32, lg: 34 }),
  },
  h4: {
    fontWeight: 700,
    fontFamily: primaryFont.style.fontFamily,
    lineHeight: 1.4,
    fontSize: pxToRem(24),
    ...responsiveFontSizes({ sm: 26, md: 28, lg: 30 }),
  },
  h5: {
    fontWeight: 600,
    fontFamily: primaryFont.style.fontFamily,
    lineHeight: 1.5,
    fontSize: pxToRem(20),
  },
  h6: {
    fontWeight: 600,
    fontFamily: primaryFont.style.fontFamily,
    lineHeight: 1.5,
    fontSize: pxToRem(18),
  },

  // Subtitles
  subtitle1: {
    fontWeight: 500,
    lineHeight: 1.5,
    fontSize: pxToRem(17),
  },
  subtitle2: {
    fontWeight: 500,
    lineHeight: 1.4,
    fontSize: pxToRem(15),
  },

  // Body
  body1: {
    lineHeight: 1.65,
    fontSize: pxToRem(16),
  },
  body2: {
    lineHeight: 1.55,
    fontSize: pxToRem(14.5),
  },

  // Small text
  caption: {
    lineHeight: 1.4,
    fontSize: pxToRem(12),
    color: "#6B7280",
  },
  overline: {
    fontWeight: 600,
    lineHeight: 1.5,
    fontSize: pxToRem(12),
    textTransform: "uppercase",
    letterSpacing: "0.08em",
  },

  // Buttons / Links
  button: {
    fontWeight: 600,
    lineHeight: 1.6,
    fontSize: pxToRem(16),
    textTransform: "none",
    letterSpacing: "0.02em",
  },
} as const;
