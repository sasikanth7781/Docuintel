import { alpha } from "@mui/material/styles";

export type ColorSchema =
  | "primary"
  | "secondary"
  | "info"
  | "success"
  | "warning"
  | "error";

declare module "@mui/material/styles" {
  interface TypeBackground {
    neutral: string;
  }
  interface SimplePaletteColorOptions {
    lighter: string;
    darker: string;
  }
  interface PaletteColor {
    lighter: string;
    darker: string;
  }
}



export const grey = {
  0: "#FFFFFF",
  100: "#F9FAFB",
  200: "#F4F6F8",
  300: "#E0E0E0",
  400: "#BDBDBD",
  500: "#9E9E9E",
  600: "#757575",
  700: "#616161",
  800: "#424242",
  900: "#212121",
};


// BRAND COLORS
export const primary = {
  lighter: "#EAF4FF",
  light: "#B3D4FF",
  main: "#4A90E2", // Elegant soft blue
  dark: "#2D6FC1",
  darker: "#1B4F91",
  contrastText: "#FFFFFF",
};

export const secondary = {
  lighter: "#F5EFFF",
  light: "#D6C2FF",
  main: "#9B6EF3", // Soft violet
  dark: "#6A3EC1",
  darker: "#472A91",
  contrastText: "#FFFFFF",
};

export const info = {
  lighter: "#E0F7FA",
  light: "#80DEEA",
  main: "#26C6DA",
  dark: "#00ACC1",
  darker: "#007C91",
  contrastText: "#FFFFFF",
};

export const background = {
  default: "#F9FAFB",
  paper: "#FFFFFF",
  neutral: "#F3F6F9",
};



export const success = {
  lighter: "#E6F4EA",
  light: "#A5D6A7",
  main: "#66BB6A",
  dark: "#43A047",
  darker: "#2E7D32",
  contrastText: "#FFFFFF",
};


export const warning = {
  lighter: "#FFF8E1",
  light: "#FFE082",
  main: "#FFB300",
  dark: "#FFA000",
  darker: "#FF8F00",
  contrastText: "#212B36",
};


export const error = {
  lighter: "#FFEBEE",
  light: "#EF9A9A",
  main: "#E53935",
  dark: "#D32F2F",
  darker: "#C62828",
  contrastText: "#FFFFFF",
};

// COMMON
export const common = {
  black: "#000000",
  white: "#FFFFFF",
};

// ACTIONS
export const action = {
  hover: alpha(grey[500], 0.08),
  selected: alpha(grey[500], 0.16),
  disabled: alpha(grey[500], 0.5),
  disabledBackground: alpha(grey[500], 0.24),
  focus: alpha(grey[500], 0.24),
  hoverOpacity: 0.08,
  disabledOpacity: 0.48,
};


// BASE
const base = {
  primary,
  secondary,
  info,
  success,
  warning,
  error,
  grey,
  common,
  divider: alpha(grey[500], 0.2),
  action,
  background
};

// ----------------------------------------------------------------------

export function palette(mode: "light" | "dark") {
  const isLight = mode === "light";

  return {
    ...base,
    mode,
    text: {
      primary: isLight ? grey[800] : grey[100],
      secondary: isLight ? grey[600] : grey[400],
      disabled: isLight ? grey[500] : grey[600],
    },
    background: {
      paper: isLight ? base.background.paper : grey[800],
      default: isLight ? base.background.default : "#121721",
      neutral: isLight ? base.background.neutral : alpha(grey[500], 0.08),
    },
    divider: isLight ? alpha(grey[500], 0.12) : alpha(grey[500], 0.24),
    action: {
      ...base.action,
      active: isLight ? grey[700] : grey[400],
      hover: alpha(isLight ? grey[500] : grey[100], 0.08),
      selected: alpha(isLight ? grey[500] : grey[100], 0.16),
      disabled: alpha(grey[500], 0.4),
      disabledBackground: alpha(grey[500], 0.24),
      focus: alpha(grey[500], 0.24),
    },
  };
}
