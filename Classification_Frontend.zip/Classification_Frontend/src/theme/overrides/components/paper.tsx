import { Theme, alpha } from '@mui/material/styles';

// ----------------------------------------------------------------------

export function paper(theme: Theme) {
  return {
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
          backdropFilter: "blur(8px)",
          backgroundColor: alpha("#fff", 0.95),
        },
        outlined: {
          borderColor: alpha(theme.palette.grey[500], 0.16),
          borderRadius: 12,
        },
      },
    },
  };
}

