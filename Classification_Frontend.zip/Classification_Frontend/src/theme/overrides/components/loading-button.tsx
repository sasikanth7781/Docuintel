import { Theme } from '@mui/material/styles';


export function loadingButton(theme: Theme) {
    return {
        MuiLoadingButton: {
            styleOverrides: {
                MuiLoadingButtonContainedPrimary:
                {
                    color: theme.palette.common.white,
                    backgroundColor: theme.palette.primary.main,
                    '&:hover': {
                        backgroundColor: theme.palette.primary.dark
                    }
                },
                MuiLoadingButtonContained:
                {
                    color: theme.palette.common.white,
                    backgroundColor: theme.palette.primary.main,
                    '&:hover': {
                        backgroundColor: theme.palette.primary.dark

                    }
                },
            }
        }
    }
}
