import { alpha, Theme } from "@mui/material/styles";
import { ButtonProps, buttonClasses } from "@mui/material/Button";

const COLORS = ["primary", "secondary", "info", "success", "warning", "error"] as const;

declare module "@mui/material/Button" {
  interface ButtonPropsVariantOverrides {
    soft: true;
  }
}

export function button(theme: Theme) {
  const lightMode = theme.palette.mode === "light";

  const rootStyles = (ownerState: ButtonProps) => {
    const inheritColor = ownerState.color === "inherit";

    const contained = ownerState.variant === "contained";
    const outlined = ownerState.variant === "outlined";
    const text = ownerState.variant === "text";
    const soft = ownerState.variant === "soft";

    const small = ownerState.size === "small";
    const medium = ownerState.size === "medium";
    const large = ownerState.size === "large";

    const defaultStyle = {
      borderRadius: 12,
      fontWeight: 600,
      textTransform: "none",
      transition: "all 0.25s ease-in-out",
      fontSize: theme.typography.button.fontSize,

      ...(inheritColor && {
        ...(contained && {
          color: lightMode ? theme.palette.common.white : theme.palette.grey[900],
          background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
          boxShadow: theme.shadows[2],
          "&:hover": {
            background: `linear-gradient(135deg, ${theme.palette.primary.dark}, ${theme.palette.primary.main})`,
            boxShadow: theme.shadows[4],
          },
        }),
        ...(outlined && {
          borderWidth: 2,
          borderColor: alpha(theme.palette.grey[500], 0.4),
          "&:hover": {
            backgroundColor: alpha(theme.palette.grey[500], 0.1),
            borderColor: theme.palette.text.primary,
          },
        }),
        ...(text && {
          "&:hover": {
            backgroundColor: alpha(theme.palette.grey[500], 0.08),
          },
        }),
        ...(soft && {
          color: theme.palette.text.primary,
          backgroundColor: alpha(theme.palette.grey[500], 0.1),
          "&:hover": {
            backgroundColor: alpha(theme.palette.grey[500], 0.2),
          },
        }),
      }),

      ...(outlined && {
        "&:hover": {
          borderColor: theme.palette.primary.main,
          boxShadow: `0 0 0 2px ${alpha(theme.palette.primary.main, 0.3)}`,
        },
      }),
    };

    const colorStyle = COLORS.map((color) => ({
      ...(ownerState.color === color && {
        ...(contained && {
          background: `linear-gradient(135deg, ${theme.palette[color].main}, ${theme.palette[color].dark})`,
          "&:hover": {
            background: `linear-gradient(135deg, ${theme.palette[color].dark}, ${theme.palette[color].main})`,
            boxShadow: theme.customShadows?.[color] ?? theme.shadows[3],
          },
        }),
        ...(soft && {
          color: theme.palette[color][lightMode ? "dark" : "light"],
          backgroundColor: alpha(theme.palette[color].main, 0.15),
          "&:hover": {
            backgroundColor: alpha(theme.palette[color].main, 0.3),
          },
        }),
      }),
    }));

    const disabledState = {
      [`&.${buttonClasses.disabled}`]: {
        opacity: 0.5,
        cursor: "not-allowed",
        boxShadow: "none",
        ...(soft && {
          backgroundColor: theme.palette.action.disabledBackground,
        }),
      },
    };

    const size = {
      ...(small && {
        height: 32,
        fontSize: theme.typography.pxToRem(13),
        padding: "4px 12px",
      }),
      ...(medium && {
        height: 42,
        fontSize: theme.typography.pxToRem(15),
        padding: "6px 18px",
      }),
      ...(large && {
        height: 50,
        fontSize: theme.typography.pxToRem(16),
        padding: "8px 24px",
      }),
    };

    return [defaultStyle, ...colorStyle, disabledState, size];
  };

  return {
    MuiButton: {
      styleOverrides: {
        root: ({ ownerState }: { ownerState: ButtonProps }) => rootStyles(ownerState),
      },
    },
  };
}
