"use client";

import { Container, Paper, Typography, Button } from "@mui/material";

export default function NotFoundPage() {
    return (
        <Container maxWidth="sm">
            <Paper
                elevation={3}
                sx={{
                    mt: 10,
                    p: 5,
                    textAlign: "center",
                    borderRadius: 3,
                }}
            >
                <Typography variant="h4" gutterBottom>
                    🚧 Page Not Implemented
                </Typography>

                <Typography variant="body1" color="text.secondary" gutterBottom>
                    Sorry, the page you are looking for does not exist or is not implemented yet.
                </Typography>

                <Button
                    variant="contained"
                    color="primary"
                    href="/"
                    sx={{ mt: 3 }}
                >
                    Go Back Home
                </Button>
            </Paper>
        </Container>
    );
}
