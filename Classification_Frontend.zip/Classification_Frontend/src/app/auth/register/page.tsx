"use client";

import {
    Box,
    Button,
    Divider,
    MenuItem,
    Stack,
    TextField,
    Typography,
    useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { LoadingButton } from "@mui/lab";
import { callPostApiWithData } from "../../../api/api";
import SecureStorage from "react-secure-storage";
import { useSnackbar } from "../../../components/snackbar";
import OutlinedPassword from "@/components/password";
import AppConstant from "@/app/constant/AppConstant";


const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;

const validationSchema = Yup.object({
    firstName: Yup.string().required("First Name is required"),
    lastName: Yup.string().required("Last Name is required"),
    email: Yup.string().email("Invalid email").required("Email is required"),
    password: Yup.string()
        .required(AppConstant.PASSWORD_REQUIRED)
        .matches(
            passwordRules,
            AppConstant.VALID_PASSWORD
        ),
    confirmPassword: Yup.string()
        .oneOf([Yup.ref("password")], "Passwords must match")
        .required("Confirm your password"),
    company: Yup.string().required("Company is required")
});

export default function RegisterPage() {
    const router = useRouter();
    const { enqueueSnackbar } = useSnackbar();
    const [loading, setLoading] = useState(false);
    const theme = useTheme();

    const formik = useFormik({
        initialValues: {
            firstName: "",
            lastName: "",
            email: "",
            password: "",
            confirmPassword: "",
            company: ""
        },
        validationSchema,
        onSubmit: async (values) => {
            try {
                setLoading(true);
                const onSuccess = (res: any) => {
                    setLoading(false);
                    enqueueSnackbar(res.message, { variant: "success" });
                    SecureStorage.setItem("email", values.email);
                    setTimeout(() => {
                        router.push(`/auth/otp-verification`);
                    }, 1200);
                };

                const onError = (err: any) => {
                    setLoading(false);
                    const message =
                        err?.response?.data.error === "Email already registered"
                            ? err.response.data.error
                            : "Error while creating user. Please try again.";
                    enqueueSnackbar(message, { variant: "error" });
                };

                const requestData = {
                    email: values.email,
                    password: values.password,
                    first_name: values.firstName,
                    last_name: values.lastName,
                    company_name: values.company,
                };

                callPostApiWithData("customer", "register", requestData, onSuccess, onError);
            } catch {
                enqueueSnackbar("Error while creating user. Please try again.", {
                    variant: "error",
                });
            }
        },
    });

    return (
        <Box
            sx={{
                minHeight: "100vh",
                width: "100vw",
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                backgroundColor: "background.default",
            }}
        >
            {/* Left: Form */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    px: { xs: 3, md: 8 },
                    py: { xs: 6, md: 10 },
                }}
            >
                <Box sx={{ width: "100%", maxWidth: 520 }}>
                    <Stack spacing={5}>
                        {/* Heading */}
                        <Box>
                            <Typography
                                variant="h2"
                                fontWeight={800}
                                sx={{
                                    background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    letterSpacing: "-0.5px",
                                    lineHeight: 1.1,
                                    fontSize: { xs: "2.2rem", md: "2.8rem" },
                                }}
                            >
                                Create Account
                            </Typography>
                            <Typography
                                variant="subtitle1"
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    fontWeight: 400,
                                    fontSize: "1.05rem",
                                    lineHeight: 1.6,
                                }}
                            >
                                Join SoftDoc AI and automate your documents with intelligence.
                            </Typography>
                        </Box>

                        {/* Form */}
                        <form onSubmit={formik.handleSubmit}>
                            <Stack spacing={2.5}>
                                <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                                    <TextField
                                        label="First Name"
                                        name="firstName"
                                        fullWidth
                                        value={formik.values.firstName}
                                        onChange={formik.handleChange}
                                        error={formik.touched.firstName && Boolean(formik.errors.firstName)}
                                        helperText={formik.touched.firstName && formik.errors.firstName}
                                    />
                                    <TextField
                                        label="Last Name"
                                        name="lastName"
                                        fullWidth
                                        value={formik.values.lastName}
                                        onChange={formik.handleChange}
                                        error={formik.touched.lastName && Boolean(formik.errors.lastName)}
                                        helperText={formik.touched.lastName && formik.errors.lastName}
                                    />
                                </Stack>

                                <TextField
                                    label="Company"
                                    name="company"
                                    fullWidth
                                    value={formik.values.company}
                                    onChange={formik.handleChange}
                                    error={formik.touched.company && Boolean(formik.errors.company)}
                                    helperText={formik.touched.company && formik.errors.company}
                                />

                                {/* <TextField
                                    select
                                    label="Role"
                                    name="role"
                                    fullWidth
                                    value={formik.values.role}
                                    onChange={formik.handleChange}
                                    error={formik.touched.role && Boolean(formik.errors.role)}
                                    helperText={formik.touched.role && formik.errors.role}
                                >
                                    {roles.map((role) => (
                                        <MenuItem key={role.value} value={role.value}>
                                            {role.label}
                                        </MenuItem>
                                    ))}
                                </TextField> */}


                                <TextField
                                    label="Email"
                                    name="email"
                                    type="email"
                                    fullWidth
                                    value={formik.values.email}
                                    onChange={formik.handleChange}
                                    error={formik.touched.email && Boolean(formik.errors.email)}
                                    helperText={formik.touched.email && formik.errors.email}
                                />

                                <OutlinedPassword
                                    name="password"
                                    value={formik.values.password}
                                    onChange={formik.handleChange}
                                    error={formik.touched.password && Boolean(formik.errors.password)}
                                    helperText={formik.touched.password && formik.errors.password}
                                />

                                <OutlinedPassword
                                    label="Confirm Password"
                                    name="confirmPassword"
                                    value={formik.values.confirmPassword}
                                    onChange={formik.handleChange}
                                    error={formik.touched.confirmPassword && Boolean(formik.errors.confirmPassword)}
                                    helperText={formik.touched.confirmPassword && formik.errors.confirmPassword}
                                />

                                <LoadingButton
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    loading={loading}
                                    sx={{
                                        py: 1.5,
                                        borderRadius: 2,
                                        fontWeight: 600,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                        boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                                    }}
                                >
                                    Register
                                </LoadingButton>
                            </Stack>
                        </form>
                    </Stack>
                </Box>
            </Box>

            {/* Right: Illustration */}
            <Box
                sx={{
                    flex: 1,
                    display: { xs: "none", md: "flex" },
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "background.neutral",
                    px: 4,
                }}
            >
                <img
                    src="/undraw_artificial-intelligence_43qa.svg"
                    alt="AI Document Processing Illustration"
                    style={{ maxWidth: "80%", height: "auto" }}
                />
            </Box>
        </Box>
    );
}
