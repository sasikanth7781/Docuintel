"use client";

import {
  Box,
  Button,
  Stack,
  TextField,
  Typography,
  Paper,
  CircularProgress,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { useFormik } from "formik";
import * as Yup from "yup";
import OutlinedPassword from "@/components/password";
import AppConstant from "@/app/constant/AppConstant";
import { useSnackbar } from "@/components/snackbar";
import { callPostApiWithData } from "@/api/api";
import { setEmail, setTokens, setUserName } from "@/utils/tokenHelper";
import { useState } from "react";

// Validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;

const validationSchema = Yup.object().shape({
  email: Yup.string()
    .matches(emailRegex, AppConstant.VALID_EMAIL_ADDRESS)
    .required(AppConstant.EMAIL_IS_REQUIRED),

  password: Yup.string()
    .required(AppConstant.PASSWORD_REQUIRED)
    .matches(passwordRules, AppConstant.VALID_PASSWORD),
});

export default function LoginPage() {
  const router = useRouter();
  const { enqueueSnackbar } = useSnackbar();
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },

    validationSchema,

    onSubmit: async (values) => {
      if (loading) return;

      setLoading(true);

      try {
        const requestData = {
          username: values.email,
          password: values.password,
        };

        const onSuccess = (res: any) => {
          setLoading(false);
          enqueueSnackbar("Login successful.", { variant: "success" });
          setTokens(res.access, res.refresh);
          setUserName(res.first_name, res.last_name);
          setEmail(res.email);

          setTimeout(() => {
            router.push("/user/data-extraction");
          }, 800);
        };

        const onError = (err: any) => {
          enqueueSnackbar(err?.response?.data?.error || "Login failed", {
            variant: "error",
          });
          setLoading(false);
        };

        callPostApiWithData("customer", "login", requestData, onSuccess, onError);
      } catch {
        enqueueSnackbar("Unexpected login error.", { variant: "error" });
        setLoading(false);
      }
    },
  });

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        background: "linear-gradient(120deg,#f6f9ff,#eef3ff)",
      }}
    >
      {/* LEFT SIDE LOGIN */}
      {/* Left: Login Form */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          px: { xs: 3, md: 6 },
          background:
            "linear-gradient(180deg, rgba(255,255,255,0.9) 0%, rgba(245,247,252,0.9) 100%)",
        }}
      >
        <Box
          sx={{
            width: "100%",
            maxWidth: 420,
            p: 5,
            borderRadius: 4,
            background: "rgba(255,255,255,0.85)",
            backdropFilter: "blur(12px)",
            boxShadow: "0 20px 60px rgba(0,0,0,0.08)",
            border: "1px solid rgba(0,0,0,0.05)",
          }}
        >
          <Stack spacing={4}>
            {/* Logo + Heading */}
            <Box textAlign="center">
              <Typography
                variant="h3"
                fontWeight={800}
                sx={{
                  background: "linear-gradient(90deg,#4A90E2,#9B6EF3)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  letterSpacing: "-0.4px",
                }}
              >
                SoftDoc AI
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
                sx={{ mt: 1.5 }}
              >
                Smart document automation platform
              </Typography>
            </Box>

            {/* Login Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                formik.handleSubmit();
              }}
            >
              <Stack spacing={3}>
                <TextField
                  label="Email Address"
                  name="email"
                  type="email"
                  fullWidth
                  size="medium"
                  value={formik.values.email}
                  onChange={formik.handleChange}
                  error={formik.touched.email && Boolean(formik.errors.email)}
                  helperText={formik.touched.email && formik.errors.email}
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 2,
                    },
                  }}
                />

                <OutlinedPassword
                  name="password"
                  label="Password"
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  error={formik.touched.password && Boolean(formik.errors.password)}
                  helperText={formik.touched.password && formik.errors.password}
                />

                <Button
                  type="submit"
                  variant="contained"
                  fullWidth
                  disabled={loading}
                  sx={{
                    textTransform: "none",
                    fontWeight: 700,
                    py: 1.6,
                    borderRadius: 2,
                    fontSize: "1rem",
                    background: "linear-gradient(90deg,#4A90E2 0%, #9B6EF3 100%)",
                    boxShadow: "0 8px 24px rgba(74,144,226,0.35)",
                    transition: "all .2s",
                    position: "relative",
                    "&:hover": {
                      transform: "translateY(-2px)",
                      boxShadow: "0 12px 30px rgba(74,144,226,0.4)",
                      background: "linear-gradient(90deg,#4A90E2 0%, #9B6EF3 100%)",
                    },
                  }}
                >
                  {loading ? (
                    <CircularProgress
                      size={24}
                      thickness={5}
                      sx={{
                        color: "white",
                      }}
                    />
                  ) : (
                    "Sign In"
                  )}
                </Button>

                {/* Links */}
                <Stack
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                  sx={{ pt: 1 }}
                >
                  <Button
                    variant="text"
                    size="small"
                    sx={{ textTransform: "none", fontWeight: 500 }}
                    onClick={() => router.push("/auth/forgot-password")}
                  >
                    Forgot password?
                  </Button>

                  <Button
                    variant="text"
                    size="small"
                    sx={{ textTransform: "none", fontWeight: 500 }}
                    onClick={() => router.push("/auth/register")}
                  >
                    Register
                  </Button>
                </Stack>
              </Stack>
            </form>
          </Stack>
        </Box>
      </Box>

      {/* RIGHT SIDE */}
      {/* Right: Illustration */}
      {/* Right: Illustration Section */}
      <Box
        sx={{
          flex: 1,
          display: { xs: "none", md: "flex" },
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
          px: 8,
          background: "linear-gradient(135deg,#f3f6ff 0%, #eef2ff 100%)",
          overflow: "hidden",
        }}
      >
        {/* Glow effect */}
        <Box
          sx={{
            position: "absolute",
            width: 420,
            height: 420,
            background:
              "radial-gradient(circle at center, rgba(123,97,255,0.25), transparent 70%)",
            filter: "blur(70px)",
            top: "-120px",
            right: "-120px",
            zIndex: 0,
          }}
        />

        <Box
          sx={{
            position: "relative",
            zIndex: 1,
            textAlign: "center",
            maxWidth: 460,
          }}
        >
          {/* Badge */}
          <Typography
            sx={{
              display: "inline-block",
              px: 2.2,
              py: 0.6,
              borderRadius: 5,
              fontSize: 12,
              fontWeight: 600,
              background: "linear-gradient(90deg,#4A90E2,#9B6EF3)",
              color: "#fff",
              mb: 2,
              letterSpacing: ".4px",
            }}
          >
            AI POWERED PLATFORM
          </Typography>

          {/* Heading */}
          <Typography
            variant="h4"
            fontWeight={800}
            sx={{
              mb: 2,
              lineHeight: 1.35,
              fontSize: "1.9rem",
              background: "linear-gradient(90deg,#4A90E2,#9B6EF3)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Automate Document
            <br />
            Processing with AI
          </Typography>

          {/* Subtitle */}
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{
              mb: 4,
              fontSize: "0.95rem",
              lineHeight: 1.6,
            }}
          >
            Upload, classify, and extract data from documents effortlessly using
            intelligent automation.
          </Typography>

          {/* Illustration */}
          <Box
            component="img"
            src="/undraw_artificial-intelligence_43qa.svg"
            alt="AI Illustration"
            sx={{
              width: "100%",
              maxWidth: 320,
              mx: "auto",
              display: "block",
              filter: "drop-shadow(0 16px 40px rgba(0,0,0,0.15))",
              transition: "transform .3s ease",
              "&:hover": {
                transform: "scale(1.04)",
              },
            }}
          />
        </Box>
      </Box>
    </Box>
  );
}