"use client";

import {
    Box,
    Button,
    Stack,
    TextField,
    Typography,
    useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPostApiWithData } from "@/api/api";
import { useRouter } from "next/navigation";
import { useSnackbar } from "@/components/snackbar";
import SecureStorage from "react-secure-storage";

const ForgotSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email").required("Email is required"),
});

export default function ForgotPasswordPage() {
    const router = useRouter();
    const { enqueueSnackbar } = useSnackbar();
    const theme = useTheme();

    const formik = useFormik({
        initialValues: {
            email: "",
        },
        validationSchema: ForgotSchema,
        onSubmit: (values) => {
            try {
                const requestData = { email: values.email };

                const onSuccess = (res: any) => {
                    enqueueSnackbar(res.message, { variant: "success" });
                    SecureStorage.setItem("email", values.email);
                    // setTimeout(() => {
                    //     router.push(`/auth/admin/update-password`);
                    // }, 1200);
                };

                const onError = (err: any) => {
                    console.log(err, "err dat");
                    enqueueSnackbar(err.response.data.error, { variant: "error" });
                };

                callPostApiWithData("customer", "forgot-password", requestData, onSuccess, onError);
            } catch {
                enqueueSnackbar("Error while sending OTP.", { variant: "error" });
            }
        },
    });

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                backgroundColor: "background.default",
                overflow: "hidden",
            }}
        >
            {/* Left: Form */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    px: { xs: 3, md: 8 },
                }}
            >
                <Box sx={{ width: "100%", maxWidth: 400 }}>
                    <Stack spacing={5}>
                        {/* Heading */}
                        <Box>
                            <Typography
                                variant="h4"
                                fontWeight={700}
                                sx={{
                                    background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    letterSpacing: "-0.4px",
                                    lineHeight: 1.2,
                                    fontSize: { xs: "1.8rem", md: "2.2rem" },
                                }}
                            >
                                Forgot Password
                            </Typography>
                            <Typography
                                variant="subtitle1"
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    fontWeight: 400,
                                    fontSize: "1rem",
                                    lineHeight: 1.6,
                                }}
                            >
                                Enter your email and we’ll send you a one-time password (OTP) to verify your identity and reset your password.
                            </Typography>
                        </Box>

                        {/* Form */}
                        <form onSubmit={formik.handleSubmit}>
                            <Stack spacing={2.5}>
                                <TextField
                                    fullWidth
                                    label="Email Address"
                                    name="email"
                                    type="email"
                                    value={formik.values.email}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                    error={formik.touched.email && Boolean(formik.errors.email)}
                                    helperText={formik.touched.email && formik.errors.email}
                                />

                                <Button
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 600,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                        boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                                    }}
                                >
                                    Send OTP
                                </Button>
                            </Stack>
                        </form>
                    </Stack>
                </Box>
            </Box>

            {/* Right: Illustration */}
            <Box
                sx={{
                    flex: 1,
                    display: { xs: "none", md: "flex" },
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "background.neutral",
                    px: 4,
                }}
            >
                <img
                    src="/undraw_artificial-intelligence_43qa.svg"
                    alt="AI Password Recovery Illustration"
                    style={{ maxHeight: "80vh", width: "auto" }}
                />
            </Box>
        </Box>
    );
}
