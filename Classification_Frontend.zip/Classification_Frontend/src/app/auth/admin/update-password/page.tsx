"use client";

import {
    Box,
    Button,
    Stack,
    TextField,
    Typography,
    useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPostApiWithData } from "@/api/api";
import { useRouter } from "next/navigation";
import { useSnackbar } from "@/components/snackbar";
import OutlinedPassword from "@/components/password";
import SecureStorage from "react-secure-storage";
import AppConstant from "@/app/constant/AppConstant";


const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;
const UpdatePasswordSchema = Yup.object().shape({
    otp: Yup.string()
        .required("OTP is required")
        .matches(/^\d{6}$/, "OTP must be exactly 6 digits"),
    newPassword: Yup.string()
        .required("New password is required")
        .matches(
            passwordRules,
            AppConstant.VALID_PASSWORD
        ),
    confirmPassword: Yup.string()
        .oneOf([Yup.ref("newPassword")], "Passwords must match")
        .required("Confirm your new password"),
});

export default function UpdatePasswordPage() {
    const router = useRouter();
    const { enqueueSnackbar } = useSnackbar();
    const theme = useTheme();

    const formik = useFormik({
        initialValues: {
            otp: "",
            newPassword: "",
            confirmPassword: "",
        },
        validationSchema: UpdatePasswordSchema,
        onSubmit: (values) => {
            try {
                const email = SecureStorage.getItem("email"); // or SecureStorage if used earlier
                const requestData = {
                    email,
                    otp: values.otp,
                    new_password: values.newPassword,
                };

                const onSuccess = (res: any) => {
                    enqueueSnackbar(res.message, { variant: "success" });
                    router.push("/auth/admin/login");
                };

                const onError = (err: any) => {
                    enqueueSnackbar(err.response.data.error, { variant: "error" });
                };

                callPostApiWithData("customer", "forgot-password-verify", requestData, onSuccess, onError);
            } catch {
                enqueueSnackbar("Error while updating password.", { variant: "error" });
            }
        },
    });

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                backgroundColor: "background.default",
                overflow: "hidden",
            }}
        >
            {/* Left: Form */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    px: { xs: 3, md: 8 },
                }}
            >
                <Box sx={{ width: "100%", maxWidth: 400 }}>
                    <Stack spacing={5}>
                        {/* Heading */}
                        <Box>
                            <Typography
                                variant="h4"
                                fontWeight={700}
                                sx={{
                                    background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    letterSpacing: "-0.4px",
                                    lineHeight: 1.2,
                                    fontSize: { xs: "1.8rem", md: "2.2rem" },
                                }}
                            >
                                Update Password
                            </Typography>
                            <Typography
                                variant="subtitle1"
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    fontWeight: 400,
                                    fontSize: "1rem",
                                    lineHeight: 1.6,
                                }}
                            >
                                Enter the OTP sent to your email and choose a new password to complete the reset.
                            </Typography>
                        </Box>

                        {/* Form */}
                        <form onSubmit={formik.handleSubmit}>
                            <Stack spacing={2.5}>
                                <TextField
                                    fullWidth
                                    label="OTP Code"
                                    name="otp"
                                    type="tel"
                                    inputMode="numeric"
                                    value={formik.values.otp}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                    error={formik.touched.otp && Boolean(formik.errors.otp)}
                                    helperText={formik.touched.otp && formik.errors.otp}
                                />

                                <OutlinedPassword
                                    label="New Password"
                                    name="newPassword"
                                    value={formik.values.newPassword}
                                    onChange={formik.handleChange}
                                    error={formik.touched.newPassword && Boolean(formik.errors.newPassword)}
                                    helperText={formik.touched.newPassword && formik.errors.newPassword}
                                />

                                <OutlinedPassword
                                    label="Confirm New Password"
                                    name="confirmPassword"
                                    value={formik.values.confirmPassword}
                                    onChange={formik.handleChange}
                                    error={formik.touched.confirmPassword && Boolean(formik.errors.confirmPassword)}
                                    helperText={formik.touched.confirmPassword && formik.errors.confirmPassword}
                                />

                                <Button
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 600,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                        boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                                    }}
                                >
                                    Update Password
                                </Button>
                            </Stack>
                        </form>
                    </Stack>
                </Box>
            </Box>

            {/* Right: Illustration */}
            <Box
                sx={{
                    flex: 1,
                    display: { xs: "none", md: "flex" },
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "background.neutral",
                    px: 4,
                }}
            >
                <img
                    src="/undraw_artificial-intelligence_43qa.svg"
                    alt="AI Password Update Illustration"
                    style={{ maxHeight: "80vh", width: "auto" }}
                />
            </Box>
        </Box>
    );
}
