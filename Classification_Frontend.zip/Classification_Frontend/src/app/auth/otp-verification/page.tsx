"use client";

import {
    Box,
    Button,
    Stack,
    TextField,
    Typography,
    useTheme,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import { callPostApiWithData } from "@/api/api";
import SecureStorage from "react-secure-storage";
import { useRouter } from "next/navigation";
import { useSnackbar } from "../../../components/snackbar";
import { setTokens, setUserName } from "@/utils/tokenHelper";
import { LoadingButton } from "@mui/lab";
import { useState, useRef } from "react";

const OtpSchema = Yup.object().shape({
    otp: Yup.string()
        .required("OTP is required")
        .matches(/^\d{6}$/, "OTP must be exactly 6 digits"),
});

export default function OtpVerification() {
    const router = useRouter();
    const { enqueueSnackbar } = useSnackbar();
    const theme = useTheme();
    const [loading, setLoading] = useState(false);
    const [resendLoading, setResendLoading] = useState(false);
    const resendLockRef = useRef(false);

    const formik = useFormik({
        initialValues: {
            otp: "",
        },
        validationSchema: OtpSchema,
        onSubmit: (values) => {
            if (loading) return;

            try {
                setLoading(true);

                const requestData = {
                    email: SecureStorage.getItem("email"),
                    otp: values.otp,
                };

                const onSuccess = (res: any) => {
                    setLoading(false);
                    enqueueSnackbar(res.message, { variant: "success" });
                    setUserName(res.first_name, res.last_name);
                    setTokens(res.access, res.refresh);

                    setTimeout(() => {
                        router.push("/user/data-extraction");
                    }, 1200);
                };

                const onError = (err: any) => {
                    setLoading(false);
                    const message =
                        err?.response?.data?.error || "Error while verifying OTP.";
                    enqueueSnackbar(message, { variant: "error" });
                };

                callPostApiWithData("customer", "verify-otp", requestData, onSuccess, onError);
            } catch {
                setLoading(false);
                enqueueSnackbar("Error while verifying OTP.", { variant: "error" });
            }
        },
    });

    const handleResend = () => {
        if (resendLockRef.current) return; // prevent double click

        try {
            resendLockRef.current = true;
            setResendLoading(true);

            const email = SecureStorage.getItem("email");

            callPostApiWithData(
                "customer",
                "resend-otp",
                { email },
                (res: any) => {
                    resendLockRef.current = false;
                    setResendLoading(false);
                    enqueueSnackbar(res.message, { variant: "success" });
                },
                () => {
                    resendLockRef.current = false;
                    setResendLoading(false);
                    enqueueSnackbar("Error while resending OTP.", { variant: "error" });
                }
            );
        } catch {
            resendLockRef.current = false;
            setResendLoading(false);
            enqueueSnackbar("Error while resending OTP.", { variant: "error" });
        }
    };

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                flexDirection: { xs: "column", md: "row" },
                backgroundColor: "background.default",
                overflow: "hidden",
            }}
        >
            {/* Left: Form */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    px: { xs: 3, md: 8 },
                }}
            >
                <Box sx={{ width: "100%", maxWidth: 400 }}>
                    <Stack spacing={5}>
                        {/* Heading */}
                        <Box>
                            <Typography
                                variant="h4"
                                fontWeight={700}
                                sx={{
                                    background: "linear-gradient(90deg, #4A90E2, #9B6EF3)",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    letterSpacing: "-0.4px",
                                    lineHeight: 1.2,
                                    fontSize: { xs: "1.8rem", md: "2.2rem" },
                                }}
                            >
                                Enter OTP
                            </Typography>
                            <Typography
                                variant="subtitle1"
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    fontWeight: 400,
                                    fontSize: "1rem",
                                    lineHeight: 1.6,
                                }}
                            >
                                We’ve sent a 6-digit code to your email. Enter it below to complete your registration.
                            </Typography>
                        </Box>

                        {/* Form */}
                        <form onSubmit={formik.handleSubmit}>
                            <Stack spacing={2.5}>
                                <TextField
                                    fullWidth
                                    label="OTP Code"
                                    name="otp"
                                    type="tel"
                                    inputMode="numeric"
                                    value={formik.values.otp}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                    error={formik.touched.otp && Boolean(formik.errors.otp)}
                                    helperText={formik.touched.otp && formik.errors.otp}
                                />

                                <LoadingButton
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    loading={loading}
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 600,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                        boxShadow: "0 4px 12px rgba(74, 144, 226, 0.2)",
                                    }}
                                >
                                    Continue
                                </LoadingButton>

                                <LoadingButton
                                    variant="outlined"
                                    color="info"
                                    fullWidth
                                    loading={resendLoading}
                                    onClick={handleResend}
                                    sx={{
                                        py: 1.2,
                                        borderRadius: 2,
                                        fontWeight: 500,
                                        fontSize: "1rem",
                                        textTransform: "none",
                                    }}
                                >
                                    Resend Code
                                </LoadingButton>
                            </Stack>
                        </form>
                    </Stack>
                </Box>
            </Box>

            {/* Right: Illustration */}
            <Box
                sx={{
                    flex: 1,
                    display: { xs: "none", md: "flex" },
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "background.neutral",
                    px: 4,
                }}
            >
                <img
                    src="/undraw_artificial-intelligence_43qa.svg"
                    alt="AI Document Verification Illustration"
                    style={{ maxHeight: "80vh", width: "auto" }}
                />
            </Box>
        </Box>
    );
}
