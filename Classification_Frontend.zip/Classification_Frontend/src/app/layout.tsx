import "./globals.css";
import { ReactNode } from "react";
import type { Metadata } from "next";
import ThemeProvider from "../theme";
import { SnackbarProvider } from "../components/snackbar";

export const metadata: Metadata = {
  title: "Document Processing App",
  description: "AI-powered document automation",
};

type RootLayoutProps = {
  children: ReactNode;
};

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="en">
      <body>
        <ThemeProvider>
          <SnackbarProvider>
            {children}
          </SnackbarProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
