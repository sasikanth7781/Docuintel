const AppConstant = {
    EMAIL_IS_REQUIRED: 'Email is required.',
    VALID_EMAIL_ADDRESS: 'Email must be a valid email address.',
    PASSWORD_REQUIRED: 'Password is required.',
    EMPTY_STRING: '',
    SUCCESS: 'Success',
    TOKEN: 'token',
    ACTIVE: "Active",
    INACTIVE: "Inactive",
    VALID_PASSWORD: "Password must be at least 8 characters long, include an uppercase letter, a lowercase letter, a number, and a special character"
};

export default AppConstant;