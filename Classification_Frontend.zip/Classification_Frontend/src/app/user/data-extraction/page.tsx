"use client";
import React, { useState, useRef } from "react";
import {
    Box,
    Typography,
    Button,
    Paper,
    IconButton,
    useTheme,
} from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import DeleteIcon from "@mui/icons-material/Delete";
import JSZip from "jszip";
import api from "@/api/interceptors";
import CircularProgress from "@mui/material/CircularProgress";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    FormControl,
    RadioGroup,
    FormControlLabel,
    Radio,
} from "@mui/material";

interface FolderStatus {
    id: string;
    path: string;
    files: File[];
    progress: number;
    status: "pending" | "zipping" | "uploading" | "uploaded" | "error";
}

const generateFolderId = (path: string) =>
    path + "-" + Date.now() + Math.random();

const FolderUpload: React.FC = () => {
    const theme = useTheme();
    const [folders, setFolders] = useState<FolderStatus[]>([]);
    const [dragActive, setDragActive] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [openAIModal, setOpenAIModal] = useState(false);
    const [policyMode, setPolicyMode] = useState<"update" | "recreate">("update");
    const [loading, setLoading] = useState<"standard" | "ai" | null>(null);

    /** Handle folder selection */
    const handleFolderSelect = (files: File[]) => {
        if (!files.length) return;

        const folderMap: Record<string, File[]> = {};

        files.forEach((file) => {
            const relativePath = (file as any).webkitRelativePath || file.name;
            const folderName = relativePath.split("/")[0] || "root";

            if (!folderMap[folderName]) folderMap[folderName] = [];
            folderMap[folderName].push(file);
        });

        const newFolders: FolderStatus[] = Object.entries(folderMap).map(
            ([path, files]) => ({
                id: generateFolderId(path),
                path,
                files,
                progress: 0,
                status: "pending",
            })
        );

        setFolders((prev) => [...prev, ...newFolders]);

        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setDragActive(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setDragActive(false);
    };

    const handleDrop = async (e: React.DragEvent) => {
        e.preventDefault();
        setDragActive(false);

        const items = e.dataTransfer.items;
        if (!items) return;

        const files: File[] = [];

        const readEntry = (entry: any, path = ""): Promise<void> => {
            return new Promise((resolve) => {
                if (entry.isFile) {
                    entry.file((file: File) => {
                        Object.defineProperty(file, "webkitRelativePath", {
                            value: path + file.name,
                        });

                        files.push(file);
                        resolve();
                    });
                } else if (entry.isDirectory) {
                    const reader = entry.createReader();

                    reader.readEntries(async (entries: any[]) => {
                        for (const ent of entries) {
                            await readEntry(ent, path + entry.name + "/");
                        }
                        resolve();
                    });
                }
            });
        };

        const promises: Promise<void>[] = [];

        for (let i = 0; i < items.length; i++) {
            const entry = (items[i] as any).webkitGetAsEntry?.();
            if (entry) promises.push(readEntry(entry));
        }

        await Promise.all(promises);

        handleFolderSelect(files);
    };

    const removeFolder = (id: string) => {
        setFolders((prev) => prev.filter((f) => f.id !== id));
    };

    /** Reusable folder processing */
    const processFolders = async (
        endpoint: string,
        policyMode?: "update" | "recreate",
        type?: "standard" | "ai"
    ) => {
        if (!folders.length) return;

        setLoading(type || null);

        // 🔹 Snapshot folders to prevent state mutation issues
        const foldersSnapshot = folders.map((folder) => ({
            ...folder,
            files: [...folder.files],
        }));

        try {
            for (const folder of foldersSnapshot) {
                try {
                    /** ----------------------------
                     * Step 1 : Update UI -> Zipping
                     * -----------------------------*/
                    setFolders((prev) =>
                        prev.map((f) =>
                            f.id === folder.id
                                ? { ...f, status: "zipping", progress: 0 }
                                : f
                        )
                    );

                    const zip = new JSZip();

                    /** ----------------------------
                     * Step 2 : Add files safely
                     * -----------------------------*/
                    for (const file of folder.files) {
                        if (!(file instanceof File)) continue;

                        const fileName = file.name;

                        try {
                            const buffer = await file.arrayBuffer();
                            zip.file(fileName, buffer);
                        } catch (err) {
                            console.warn("Skipping file:", fileName);
                        }
                    }

                    /** ----------------------------
                     * Step 3 : Generate ZIP
                     * -----------------------------*/
                    const zipBlob = await zip.generateAsync(
                        { type: "blob" },
                        (meta) => {
                            const progress = Math.round(meta.percent);

                            setFolders((prev) =>
                                prev.map((f) =>
                                    f.id === folder.id
                                        ? { ...f, progress }
                                        : f
                                )
                            );
                        }
                    );

                    /** ----------------------------
                     * Step 4 : Upload ZIP
                     * -----------------------------*/
                    setFolders((prev) =>
                        prev.map((f) =>
                            f.id === folder.id
                                ? { ...f, status: "uploading" }
                                : f
                        )
                    );

                    const formData = new FormData();
                    formData.append("file", zipBlob, `${folder.path}.zip`);

                    if (policyMode) {
                        formData.append("policy_mode", policyMode);
                    }

                    const response = await api.post(endpoint, formData, {
                        responseType: "blob",
                    });

                    /** ----------------------------
                     * Step 5 : Download response ZIP
                     * -----------------------------*/
                    const blob = new Blob([response.data]);
                    const url = window.URL.createObjectURL(blob);

                    const link = document.createElement("a");
                    link.href = url;
                    link.download = `${folder.path}-result.zip`;

                    document.body.appendChild(link);
                    link.click();
                    link.remove();

                    window.URL.revokeObjectURL(url);

                    /** ----------------------------
                     * Step 6 : Mark Uploaded
                     * -----------------------------*/
                    setFolders((prev) =>
                        prev.map((f) =>
                            f.id === folder.id
                                ? { ...f, status: "uploaded", progress: 100 }
                                : f
                        )
                    );
                } catch (err) {
                    console.error("Folder processing failed:", err);

                    setFolders((prev) =>
                        prev.map((f) =>
                            f.id === folder.id
                                ? { ...f, status: "error" }
                                : f
                        )
                    );
                }
            }
        } finally {
            setLoading(null);
        }
    };

    const aiSegregateFolders = () => {
        setOpenAIModal(true); // open popup instead of direct API call
    };

    const uploadAllFolders = () => {
        if (loading !== null) return;
        processFolders("categorize-zip/", undefined, "standard");
    };

    const handleAIConfirm = () => {
        if (loading !== null) return;
        setOpenAIModal(false);
        processFolders("ai-categorize-zip/", policyMode, "ai");
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                minHeight: "88vh",
                p: 3,
                background: theme.palette.background.default,
            }}
        >
            <Typography
                variant="h4"
                fontWeight={700}
                color={theme.palette.primary.main}
                mb={3}
                textAlign="center"
            >
                Upload Folders
            </Typography>

            <Paper
                elevation={6}
                sx={{
                    display: "flex",
                    flexDirection: {
                        xs: "column",
                        md: "row",
                    },
                    width: {
                        xs: "100%",
                        md: "90%"
                    },
                    maxWidth: "1300px",
                    borderRadius: 3,
                    overflow: "hidden",
                    p: 3,
                    gap: 3,
                    minHeight: 400,
                }}
            >
                {/* Drag & Drop */}
                <Box
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onClick={() => fileInputRef.current?.click()}
                    sx={{
                        flex: {
                            xs: 1,
                            md: 1.3
                        },
                        p: 4,
                        borderRadius: 3,
                        textAlign: "center",
                        cursor: "pointer",
                        border: `2px dashed ${dragActive
                            ? theme.palette.primary.main
                            : theme.palette.primary.light
                            }`,
                        backgroundColor: dragActive
                            ? "rgba(200,230,255,0.3)"
                            : "rgba(250,250,255,0.6)",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        minHeight: 380,
                        transition: "0.2s ease",
                    }}
                >
                    <CloudUploadIcon
                        sx={{
                            fontSize: 75,
                            color: theme.palette.primary.main,
                            mb: 1,
                        }}
                    />

                    <Typography
                        sx={{
                            fontWeight: 700,
                            fontSize: 22,
                            textTransform: "uppercase",
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                        }}
                    >
                        DRAG & DROP OR BROWSE
                    </Typography>

                    <Typography variant="body1" color="text.secondary">
                        Upload multiple folders (auto-zipped)
                    </Typography>

                    <input
                        ref={fileInputRef}
                        type="file"
                        hidden
                        multiple
                        {...({ webkitdirectory: "true", directory: "true" } as any)}
                        onChange={(e) =>
                            handleFolderSelect(Array.from(e.target.files || []))
                        }
                    />
                </Box>

                {/* Selected folders */}
                <Box
                    sx={{
                        flex: {
                            xs: 1,
                            md: 0.7
                        },
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: "rgba(250,250,250,0.8)",
                        display: "flex",
                        flexDirection: "column",
                        maxHeight: 380,
                        overflowY: "auto",
                    }}
                >
                    <Typography
                        variant="h6"
                        fontWeight={700}
                        color={theme.palette.primary.main}
                        mb={2}
                    >
                        Selected Folders
                    </Typography>

                    {folders.length === 0 ? (
                        <Typography color="text.secondary">
                            No folders selected yet.
                        </Typography>
                    ) : (
                        folders.map((folder) => (
                            <Paper
                                key={folder.id}
                                sx={{
                                    p: 1.4,
                                    mb: 1,
                                    borderRadius: 2,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                }}
                            >
                                <Typography fontWeight={600}>
                                    {folder.path}.zip
                                </Typography>

                                <Box sx={{ display: "flex", gap: 1 }}>
                                    {folder.status === "uploaded" && (
                                        <CheckCircleIcon color="success" />
                                    )}
                                    {folder.status === "error" && (
                                        <ErrorOutlineIcon color="error" />
                                    )}

                                    <IconButton
                                        onClick={() => removeFolder(folder.id)}
                                        size="small"
                                    >
                                        <DeleteIcon fontSize="small" />
                                    </IconButton>
                                </Box>
                            </Paper>
                        ))
                    )}
                </Box>
            </Paper>

            {folders.length > 0 && (
                <Box
                    sx={{
                        mt: 3,
                        display: "flex",
                        gap: 3,
                        flexWrap: "wrap",
                        justifyContent: "center",
                    }}
                >
                    <Button
                        variant="contained"
                        disabled={loading !== null}
                        onClick={uploadAllFolders}
                        sx={{
                            px: 5,
                            py: 1.6,
                            borderRadius: 3,
                            fontSize: 16,
                            textTransform: "none",
                            display: "flex",
                            alignItems: "center",
                            gap: 1.5,
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        }}
                    >
                        {loading === "standard" ? (
                            <>
                                <CircularProgress size={20} color="inherit" />
                                Processing...
                            </>
                        ) : (
                            <>
                                <CloudUploadIcon />
                                Standard Segregation
                            </>
                        )}
                    </Button>
                    <Button
                        variant="contained"
                        disabled={loading !== null}
                        onClick={aiSegregateFolders}
                        sx={{
                            px: 5,
                            py: 1.6,
                            borderRadius: 3,
                            fontSize: 16,
                            textTransform: "none",
                            display: "flex",
                            alignItems: "center",
                            gap: 1.5,
                            background: "linear-gradient(90deg,#7b61ff,#00c6ff)",
                        }}
                    >
                        {loading === "ai" ? (
                            <>
                                <CircularProgress size={20} color="inherit" />
                                Processing AI...
                            </>
                        ) : (
                            <>
                                <AutoAwesomeIcon />
                                AI-Powered Segregation
                            </>
                        )}
                    </Button>
                </Box>
            )}
            <Dialog open={openAIModal} onClose={() => setOpenAIModal(false)}>
                <DialogTitle>Select Policy Mode</DialogTitle>

                <DialogContent>
                    <FormControl>
                        <RadioGroup
                            value={policyMode}
                            onChange={(e) =>
                                setPolicyMode(e.target.value as "update" | "recreate")
                            }
                        >
                            <FormControlLabel
                                value="update"
                                control={<Radio />}
                                label="Update Existing Policies (Default)"
                            />
                            <FormControlLabel
                                value="recreate"
                                control={<Radio />}
                                label="Recreate Policies from Scratch"
                            />
                        </RadioGroup>
                    </FormControl>
                </DialogContent>

                <DialogActions>
                    <Button onClick={() => setOpenAIModal(false)}>Cancel</Button>
                    <Button variant="contained" onClick={handleAIConfirm}>
                        Continue
                    </Button>
                </DialogActions>
            </Dialog>

            {loading !== null && (
                <Box
                    sx={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100vw",
                        height: "100vh",
                        backdropFilter: "blur(6px)",
                        backgroundColor: "rgba(0,0,0,0.25)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 2000,
                    }}
                >
                    <Paper
                        elevation={10}
                        sx={{
                            px: 6,
                            py: 5,
                            borderRadius: 4,
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            gap: 3,
                            minWidth: 260,
                            background: "white",
                        }}
                    >
                        <CircularProgress
                            size={60}
                            sx={{
                                color:
                                    loading === "ai"
                                        ? "#7b61ff"
                                        : theme.palette.primary.main,
                            }}
                        />

                        <Typography
                            variant="h6"
                            fontWeight={700}
                            sx={{
                                background:
                                    loading === "ai"
                                        ? "linear-gradient(90deg,#7b61ff,#00c6ff)"
                                        : `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                                WebkitBackgroundClip: "text",
                                WebkitTextFillColor: "transparent",
                                textAlign: "center",
                            }}
                        >
                            {loading === "ai"
                                ? "AI Processing Folders..."
                                : "Processing Folders..."}
                        </Typography>

                        <Typography variant="body2" color="text.secondary" textAlign="center">
                            Please wait while your folders are being processed.
                        </Typography>
                    </Paper>
                </Box>
            )}

        </Box>
    );
};

export default FolderUpload;