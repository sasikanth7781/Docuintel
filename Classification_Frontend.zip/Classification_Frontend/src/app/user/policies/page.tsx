"use client";

import React, { useEffect, useState } from "react";
import {
    Box,
    Typography,
    Button,
    Stack,
    Container,
    IconButton,
    Chip,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Tooltip,
    Paper,
    useTheme,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import { useFormik } from "formik";
import * as Yup from "yup";
import OutlinedKeywordInput from "@/components/OutlinedKeywordInput";
import {
    callGetApiWithData,
    callPostApiWithData,
    callPutApiWithData,
    callDeleteApiWithData,
} from "@/api/api";
import { useSnackbar } from "@/components/snackbar";

type Policy = {
    id?: number;
    folder_name: string;
    keywords: string[];
    tempKeyword?: string;
};

export default function PoliciesPage() {
    const theme = useTheme();
    const { enqueueSnackbar } = useSnackbar();

    const [policies, setPolicies] = useState<Policy[]>([]);
    const [newPolicies, setNewPolicies] = useState<Policy[]>([]);
    const [editingPolicy, setEditingPolicy] = useState<Policy | null>(null);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [deletePolicyId, setDeletePolicyId] = useState<number | null>(null);

    const endpoint = "policies";

    useEffect(() => {
        loadPolicies();
    }, []);

    const loadPolicies = () => {
        callGetApiWithData(
            endpoint,
            null,
            {},
            (res) => setPolicies((res as Policy[]).map((p) => ({ ...p, tempKeyword: "" }))),
            () => enqueueSnackbar("Failed to fetch policies.", { variant: "error" })
        );
    };

    const formik = useFormik({
        initialValues: { folder_name: "", keywords: [] as string[] },
        enableReinitialize: true,
        validationSchema: Yup.object({
            folder_name: Yup.string().required("Folder path is required"),
        }),
        onSubmit: (values) => {
            if (editingPolicy?.id != null) {
                callPutApiWithData(
                    endpoint,
                    null,
                    editingPolicy.id.toString(),
                    { folder_name: values.folder_name, keywords: values.keywords },
                    () => {
                        enqueueSnackbar("Policy updated successfully!", { variant: "success" });
                        loadPolicies();
                        setEditingPolicy(null);
                        setDialogOpen(false);
                    },
                    () => enqueueSnackbar("Failed to update policy.", { variant: "error" })
                );
            }
        },
    });

    const handleOpenCreateDialog = () => {
        setNewPolicies([{ folder_name: "", keywords: [], tempKeyword: "" }, ...newPolicies]);
        setEditingPolicy(null);
        setDialogOpen(true);
    };

    const handleAddBlankNewPolicyCard = () => {
        setNewPolicies((prev) => [...prev, { folder_name: "", keywords: [], tempKeyword: "" }]);
    };

    const handleEditPolicy = (policy: Policy) => {
        setEditingPolicy({ ...policy, tempKeyword: "" });
        formik.setValues({ folder_name: policy.folder_name, keywords: [...policy.keywords] });
        setDialogOpen(true);
    };

    const handleKeywordAdd = (index: number, isNew: boolean) => {
        if (isNew) {
            const updated = [...newPolicies];
            const newKw = (updated[index].tempKeyword || "").trim().slice(0, 100);
            if (!newKw) return;
            if (!updated[index].keywords.includes(newKw)) updated[index].keywords.push(newKw);
            updated[index].tempKeyword = "";
            setNewPolicies(updated);
        } else if (editingPolicy) {
            const newKw = (editingPolicy.tempKeyword || "").trim();
            if (!newKw) return;
            const updatedKeywords = [...formik.values.keywords];
            if (!updatedKeywords.includes(newKw)) updatedKeywords.push(newKw);
            formik.setFieldValue("keywords", updatedKeywords);
            setEditingPolicy({ ...editingPolicy, keywords: updatedKeywords, tempKeyword: "" });
        }
    };

    const handleKeywordClick = (index: number, keyword: string, isNew: boolean) => {
        if (isNew) {
            const updated = [...newPolicies];
            updated[index].keywords = updated[index].keywords.filter((k) => k !== keyword);
            updated[index].tempKeyword = keyword;
            setNewPolicies(updated);
        } else if (editingPolicy) {
            const updatedKeywords = formik.values.keywords.filter((k) => k !== keyword);
            formik.setFieldValue("keywords", updatedKeywords);
            setEditingPolicy({ ...editingPolicy, keywords: updatedKeywords, tempKeyword: keyword });
        }
    };

    const handleRemoveKeyword = (index: number, keyword: string, isNew: boolean) => {
        if (isNew) {
            const updated = [...newPolicies];
            updated[index].keywords = updated[index].keywords.filter((k) => k !== keyword);
            if (updated[index].tempKeyword === keyword) updated[index].tempKeyword = "";
            setNewPolicies(updated);
        } else if (editingPolicy) {
            const updatedKeywords = formik.values.keywords.filter((k) => k !== keyword);
            formik.setFieldValue("keywords", updatedKeywords);
            if (editingPolicy.tempKeyword === keyword) setEditingPolicy({ ...editingPolicy, tempKeyword: "" });
            setEditingPolicy({ ...editingPolicy, keywords: updatedKeywords });
        }
    };

    const handleDeletePolicy = (id?: number) => {
        if (!id) return;
        setDeletePolicyId(id);
        setDeleteConfirmOpen(true);
    };

    const confirmDeletePolicy = () => {
        if (!deletePolicyId) return;
        callDeleteApiWithData(
            endpoint,
            null,
            deletePolicyId.toString(),
            () => {
                setPolicies((p) => p.filter((x) => x.id !== deletePolicyId));
                enqueueSnackbar("Policy deleted successfully!", { variant: "success" });
                setDeleteConfirmOpen(false);
                setDeletePolicyId(null);
            },
            () => enqueueSnackbar("Failed to delete policy.", { variant: "error" })
        );
    };

    const handleSaveNewPolicies = () => {
        if (newPolicies.length === 0) return;
        for (const p of newPolicies) {
            if (!p.folder_name || !p.folder_name.trim()) {
                enqueueSnackbar("Please provide folder path for all new policies before saving.", { variant: "warning" });
                return;
            }
        }
        const payload = newPolicies.map((p) => ({ folder_name: p.folder_name, keywords: p.keywords }));
        callPostApiWithData(
            endpoint,
            null,
            payload,
            () => {
                enqueueSnackbar("Policies created successfully!", { variant: "success" });
                loadPolicies();
                setNewPolicies([]);
                setDialogOpen(false);
            },
            () => enqueueSnackbar("Failed to create policies.", { variant: "error" })
        );
    };

    const updateNewPolicyField = (index: number, field: Partial<Policy>) => {
        setNewPolicies((prev) => {
            const updated = [...prev];

            if (!updated[index]) return prev;

            updated[index] = {
                ...updated[index],
                ...field,
            };

            return updated;
        });
    };

    const handleCloseDialog = () => {
        setDialogOpen(false);
        setEditingPolicy(null);
        setNewPolicies([]);
        formik.resetForm();
    };

    // Chip styling for add/edit keywords
    const chipStyles = {
        maxWidth: 300,
        display: "flex",
        alignItems: "center",
        cursor: "pointer",
        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
        color: "#fff",
        fontWeight: 500,
        margin: "2px",

        "&:hover": {
            transform: "scale(1.05)",
            boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
        },

        "& .MuiChip-label": {
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            display: "block",
            maxWidth: 220,
            paddingRight: 2,
        },

        "& .MuiChip-deleteIcon": {
            color: "#fff",
            fontSize: 16,
            width: 16,
            height: 16,
            marginLeft: 4,
            verticalAlign: "middle",
            "&:hover": {
                color: "#fff",
            },
        },
    };

    return (
        <Container maxWidth="lg" sx={{ py: 6 }}>
            <Stack spacing={4}>
                <Typography
                    variant="h4"
                    fontWeight={800}
                    textAlign="center"
                    sx={{
                        background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                    }}
                >
                    Manage Document Policies
                </Typography>

                <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems={{ xs: "flex-start", md: "center" }}
                    flexDirection={{ xs: "column", md: "row" }}
                    gap={{ xs: 2, md: 0 }}
                >
                    <Typography variant="subtitle1" color="text.secondary">
                        Create and manage folder-based document policies with keywords.
                    </Typography>
                    <Button
                        variant="outlined"
                        startIcon={<AddIcon />}
                        onClick={handleOpenCreateDialog}
                        sx={{
                            textTransform: "none",
                            borderRadius: 3,
                            boxShadow: "0 3px 12px rgba(0,0,0,0.08)",
                        }}
                    >
                        Add Policy
                    </Button>
                </Box>

                <Stack spacing={2}>
                    {policies.length === 0 ? (
                        <Paper sx={{ p: 4, textAlign: "center", borderRadius: 3, boxShadow: "0 6px 18px rgba(0,0,0,0.08)" }}>
                            <Typography>No policies available.</Typography>
                            <Typography variant="body2" color="text.secondary" mt={1}>
                                Click <strong>Add Policy</strong> to create new ones.
                            </Typography>
                        </Paper>
                    ) : (
                        policies.map((policy) => (
                            <Paper
                                key={policy.id}
                                sx={{
                                    p: 3,
                                    display: "flex",
                                    flexDirection: { xs: "column", md: "row" },
                                    gap: { xs: 2, md: 3 },
                                    justifyContent: "space-between",
                                    alignItems: { xs: "flex-start", md: "center" },
                                    borderRadius: 3,
                                    boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
                                }}
                            >
                                <Box
                                    sx={{
                                        flex: 1,
                                        minWidth: { xs: "100%", md: 200 }
                                    }}
                                >
                                    <Typography variant="subtitle2" fontWeight={700}>
                                        Folder Path
                                    </Typography>
                                    <Tooltip title={policy.folder_name || ""} arrow>
                                        <Typography
                                            sx={{
                                                maxWidth: 300,
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                                whiteSpace: "nowrap",
                                                cursor: "pointer"
                                            }}
                                        >
                                            {policy.folder_name || "-"}
                                        </Typography>
                                    </Tooltip>
                                </Box>

                                <Box
                                    sx={{
                                        flex: 2,
                                        maxWidth: { xs: "100%", md: "60%" }
                                    }}
                                >
                                    <Typography variant="subtitle2" fontWeight={700}>
                                        Keywords
                                    </Typography>
                                    <Stack direction="row" spacing={1} flexWrap="wrap" mt={0.5}>
                                        {policy.keywords.length ? (
                                            policy.keywords.map((kw, idx) => (
                                                <Tooltip key={idx} title={kw}>
                                                    <Chip
                                                        label={kw}
                                                        sx={{
                                                            maxWidth: 300,
                                                            display: "flex",
                                                            alignItems: "center",
                                                            cursor: "default",
                                                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                                                            color: "#fff",
                                                            fontWeight: 500,
                                                            margin: "2px",
                                                            "& .MuiChip-label": {
                                                                overflow: "hidden",
                                                                textOverflow: "ellipsis",
                                                                whiteSpace: "nowrap",
                                                            },
                                                        }}
                                                    />
                                                </Tooltip>
                                            ))
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                -
                                            </Typography>
                                        )}
                                    </Stack>
                                </Box>

                                <Stack
                                    direction="row"
                                    spacing={1}
                                    alignSelf={{ xs: "flex-end", md: "center" }}
                                >
                                    <Tooltip title="Edit Policy">
                                        <IconButton onClick={() => handleEditPolicy(policy)} sx={{ bgcolor: "transparent" }}>
                                            <EditIcon />
                                        </IconButton>
                                    </Tooltip>
                                    <Tooltip title="Delete Policy">
                                        <IconButton onClick={() => handleDeletePolicy(policy.id!)} sx={{ bgcolor: "transparent" }}>
                                            <DeleteIcon />
                                        </IconButton>
                                    </Tooltip>
                                </Stack>
                            </Paper>
                        ))
                    )}
                </Stack>

                <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
                    <DialogTitle>
                        <Stack direction="row" justifyContent="space-between" alignItems="center">
                            <Box>
                                <Typography variant="h6" fontWeight={700}>
                                    {editingPolicy ? "Edit Policy" : "Create Policies"}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" mt={0.5}>
                                    {editingPolicy
                                        ? "Update folder and keywords for this policy."
                                        : "Add multiple policies below and click Save All to create them at once."}
                                </Typography>
                            </Box>
                            {!editingPolicy && (
                                <Button variant="text" startIcon={<AddIcon />} onClick={handleAddBlankNewPolicyCard} sx={{ textTransform: "none" }}>
                                    Add another policy
                                </Button>
                            )}
                        </Stack>
                    </DialogTitle>

                    <DialogContent
                        dividers
                        sx={{
                            pt: 2,
                            maxHeight: "65vh",
                            overflowY: "auto",
                        }}
                    >
                        <Stack spacing={2}>
                            {editingPolicy ? (
                                <Paper sx={{ p: 2, borderRadius: 3, boxShadow: "0 2px 10px rgba(0,0,0,0.06)" }}>
                                    <Stack spacing={2}>
                                        <Typography variant="subtitle2" fontWeight={600}>
                                            Folder Path
                                        </Typography>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            placeholder="Enter folder path"
                                            value={formik.values.folder_name}
                                            onChange={(e) => formik.setFieldValue("folder_name", e.target.value)}
                                            error={!!(formik.touched.folder_name && formik.errors.folder_name)}
                                            helperText={formik.touched.folder_name && formik.errors.folder_name}
                                            slotProps={{
                                                input: {
                                                    inputProps: {
                                                        maxLength: 500
                                                    }
                                                }
                                            }}
                                            sx={{
                                                "& .MuiInputBase-input": {
                                                    overflowWrap: "anywhere",
                                                    wordBreak: "break-all"
                                                }
                                            }}
                                        />

                                        <Typography variant="subtitle2" fontWeight={600}>
                                            Keywords
                                        </Typography>
                                        <OutlinedKeywordInput
                                            label="Add or edit keyword"
                                            value={editingPolicy.tempKeyword || ""}
                                            onChange={(e) => setEditingPolicy({ ...editingPolicy, tempKeyword: e.target.value })}
                                            onAddKeyword={() => handleKeywordAdd(0, false)}
                                        />

                                        <Stack direction="row" spacing={1} flexWrap="wrap">
                                            {formik.values.keywords.map((kw, kidx) => (
                                                <Chip
                                                    key={kidx}
                                                    label={
                                                        <Tooltip title="Click to edit" enterDelay={200} leaveDelay={100}>
                                                            <span>{kw}</span>
                                                        </Tooltip>
                                                    }
                                                    onClick={() => handleKeywordClick(0, kw, false)}
                                                    onDelete={() => handleRemoveKeyword(0, kw, false)}
                                                    deleteIcon={
                                                        <Tooltip title="Remove keyword" enterDelay={200} leaveDelay={100}>
                                                            <span>X</span>
                                                        </Tooltip>
                                                    }
                                                    sx={chipStyles}
                                                />
                                            ))}
                                        </Stack>
                                    </Stack>
                                </Paper>
                            ) : (
                                newPolicies.map((policy, idx) => (
                                    <Paper key={idx} sx={{ p: 2, borderRadius: 3, boxShadow: "0 2px 10px rgba(0,0,0,0.06)" }}>
                                        <Stack spacing={2}>
                                            <Stack direction="row" justifyContent="space-between" alignItems="center">
                                                <Typography variant="subtitle1" fontWeight={600}>
                                                    Policy #{idx + 1}
                                                </Typography>
                                                <Button
                                                    size="small"
                                                    onClick={() => setNewPolicies((prev) => prev.filter((_, i) => i !== idx))}
                                                    sx={{ textTransform: "none" }}
                                                >
                                                    Remove
                                                </Button>
                                            </Stack>

                                            <Typography variant="subtitle2" fontWeight={600}>
                                                Folder Path
                                            </Typography>
                                            <TextField
                                                fullWidth
                                                size="small"
                                                placeholder="Enter folder path"
                                                value={policy.folder_name}
                                                onChange={(e) =>
                                                    updateNewPolicyField(idx, { folder_name: e.target.value })
                                                }
                                                slotProps={{
                                                    input: {
                                                        inputProps: {
                                                            maxLength: 500,
                                                        },
                                                    },
                                                }}
                                                sx={{
                                                    "& .MuiInputBase-input": {
                                                        overflowWrap: "anywhere",
                                                        wordBreak: "break-all",
                                                    },
                                                }}
                                            />
                                            <Typography variant="subtitle2" fontWeight={600}>
                                                Keywords
                                            </Typography>
                                            <OutlinedKeywordInput
                                                label="Add or edit keyword"
                                                value={policy.tempKeyword || ""}
                                                onChange={(e) =>
                                                    updateNewPolicyField(idx, { tempKeyword: e.target.value.slice(0, 100) })
                                                }
                                                onAddKeyword={() => handleKeywordAdd(idx, true)}
                                            />

                                            <Stack direction="row" spacing={1} flexWrap="wrap">
                                                {policy.keywords.map((kw, kidx) => (
                                                    <Chip
                                                        key={kidx}
                                                        label={
                                                            <Tooltip title="Click to edit" enterDelay={200} leaveDelay={100}>
                                                                <span>{kw}</span>
                                                            </Tooltip>
                                                        }
                                                        onClick={() => handleKeywordClick(idx, kw, true)}
                                                        onDelete={() => handleRemoveKeyword(idx, kw, true)}
                                                        deleteIcon={
                                                            <Tooltip title="Remove keyword" enterDelay={200} leaveDelay={100}>
                                                                <span>X</span>
                                                            </Tooltip>
                                                        }
                                                        sx={chipStyles}
                                                    />
                                                ))}
                                            </Stack>
                                        </Stack>
                                    </Paper>
                                ))
                            )}
                        </Stack>
                    </DialogContent>

                    <DialogActions sx={{ px: 3, py: 2, justifyContent: "flex-end", gap: 1 }}>
                        <Button onClick={handleCloseDialog}>Cancel</Button>
                        {editingPolicy ? (
                            <Button
                                variant="contained"
                                onClick={() => formik.handleSubmit()}
                                sx={{
                                    textTransform: "none",
                                    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                                }}
                            >
                                Update Policy
                            </Button>
                        ) : (
                            <Button
                                variant="contained"
                                onClick={handleSaveNewPolicies}
                                sx={{
                                    textTransform: "none",
                                    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                                }}
                            >
                                Save All Policies
                            </Button>
                        )}
                    </DialogActions>
                </Dialog>

                <Dialog open={deleteConfirmOpen} onClose={() => setDeleteConfirmOpen(false)}>
                    <DialogTitle>Confirm Delete</DialogTitle>
                    <DialogContent>
                        <Typography>Are you sure you want to delete this policy?</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
                        <Button color="error" onClick={confirmDeletePolicy}>
                            Delete
                        </Button>
                    </DialogActions>
                </Dialog>
            </Stack>
        </Container>
    );
}
