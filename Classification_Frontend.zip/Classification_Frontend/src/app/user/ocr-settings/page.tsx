"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
    Box,
    Typography,
    Paper,
    Checkbox,
    Button,
    FormControl,
    OutlinedInput,
    useTheme,
    useMediaQuery,
} from "@mui/material";
import { useSnackbar } from "@/components/snackbar";
import { callGetApiWithData, callPatchApiWithData } from "@/api/api";

interface OCRService {
    id?: number;
    key: string;
    label: string;
    enabled: boolean;
    accuracy: number;
}

const ALL_OCR_SERVICES: OCRService[] = [
    { key: "pytesseract", label: "PyTesseract", enabled: false, accuracy: 90 },
    { key: "paddleocr", label: "PaddleOCR", enabled: false, accuracy: 90 }
];

const OCRSettingsPage: React.FC = () => {

    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("md"));
    const { enqueueSnackbar } = useSnackbar();

    const [services, setServices] = useState<OCRService[]>(ALL_OCR_SERVICES);
    const [apiEnabledOcrs, setApiEnabledOcrs] = useState<OCRService[]>([]);
    const [loading, setLoading] = useState(false);

    const saveLock = React.useRef(false);

    const fetchOCRSettings = useCallback(() => {

        setLoading(true);

        callGetApiWithData(
            "ocr-settings",
            null,
            {},
            (res: any) => {

                const fetched: OCRService[] = res?.services || [];

                const merged = ALL_OCR_SERVICES.map((ocr) => {
                    const match = fetched.find((s) => s.key === ocr.key);

                    return match
                        ? { ...ocr, enabled: match.enabled, accuracy: match.accuracy, id: match.id }
                        : ocr;
                });

                setServices(merged);
                setApiEnabledOcrs(merged.filter((s) => s.enabled));

                setLoading(false);
            },
            () => {
                enqueueSnackbar("Failed to fetch OCR settings.", { variant: "error" });
                setLoading(false);
            }
        );

    }, [enqueueSnackbar]);

    useEffect(() => {
        fetchOCRSettings();
    }, [fetchOCRSettings]);

    const toggleOCR = (key: string) => {
        const updated = services.map((ocr) =>
            ocr.key === key ? { ...ocr, enabled: !ocr.enabled } : ocr
        );

        setServices(updated);
    };

    const changeAccuracy = (key: string, value: number) => {

        if (isNaN(value) || value < 0 || value > 100) return;

        const updated = services.map((ocr) =>
            ocr.key === key ? { ...ocr, accuracy: value } : ocr
        );

        setServices(updated);
    };

    const handleSave = () => {

        if (saveLock.current) return;

        saveLock.current = true;
        setLoading(true);

        const payload = {
            services: services.map(({ id, key, enabled, accuracy }) => ({
                id,
                key,
                enabled,
                accuracy
            }))
        };

        callPatchApiWithData(
            "ocr-settings",
            null,
            payload,
            (res: any) => {

                enqueueSnackbar(res?.message || "OCR settings updated!", {
                    variant: "success"
                });

                fetchOCRSettings();

                saveLock.current = false;
                setLoading(false);
            },
            () => {

                enqueueSnackbar("Failed to update OCR settings.", {
                    variant: "error"
                });

                saveLock.current = false;
                setLoading(false);
            }
        );
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                minHeight: "88vh",
                p: { xs: 2, md: 3 },
                background: theme.palette.background.default,
            }}
        >

            <Typography
                variant="h4"
                fontWeight={700}
                color={theme.palette.primary.main}
                mb={3}
                textAlign="center"
            >
                OCR Settings
            </Typography>

            <Paper
                elevation={6}
                sx={{
                    display: "flex",
                    flexDirection: isMobile ? "column" : "row",
                    width: "100%",
                    maxWidth: 1300,
                    borderRadius: 3,
                    overflow: "hidden",
                    p: { xs: 2, md: 3 },
                    gap: 3,
                }}
            >

                {/* LEFT PANEL */}

                <Box
                    sx={{
                        flex: 1.3,
                        p: { xs: 2, md: 3 },
                        borderRadius: 3,
                        border: `2px dashed ${theme.palette.primary.light}`,
                        backgroundColor: "rgba(250,250,255,0.6)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 2.5,
                    }}
                >

                    {services.map((ocr) => (

                        <Paper
                            key={ocr.key}
                            sx={{
                                p: 2.5,
                                borderRadius: 3,
                                display: "flex",
                                flexDirection: "column",
                                gap: 1.5,
                                transition: "all 0.25s ease",
                                border: ocr.enabled
                                    ? `2px solid ${theme.palette.primary.main}`
                                    : "2px solid transparent",
                                background: ocr.enabled
                                    ? "linear-gradient(90deg,#e8f0ff,#f5f9ff)"
                                    : "linear-gradient(90deg,#f7f9fc,#eef2f7)",
                                "&:hover": {
                                    transform: "scale(1.02)",
                                    boxShadow: "0 8px 20px rgba(0,0,0,0.08)",
                                },
                            }}
                        >

                            <Box
                                display="flex"
                                justifyContent="space-between"
                                alignItems="center"
                                flexWrap="wrap"
                            >
                                <Typography fontWeight={700} fontSize={18}>
                                    {ocr.label}
                                </Typography>

                                <Checkbox
                                    checked={ocr.enabled}
                                    onChange={() => toggleOCR(ocr.key)}
                                />
                            </Box>

                            {ocr.enabled && (

                                <Box
                                    display="flex"
                                    justifyContent="space-between"
                                    alignItems="center"
                                    flexWrap="wrap"
                                    gap={1}
                                >

                                    <Typography
                                        color="text.secondary"
                                        fontSize={14}
                                    >
                                        Accuracy Level
                                    </Typography>

                                    <FormControl size="small" sx={{ width: 120 }}>
                                        <OutlinedInput
                                            type="number"
                                            value={ocr.accuracy ?? ""}
                                            onChange={(e) =>
                                                changeAccuracy(
                                                    ocr.key,
                                                    parseFloat(e.target.value)
                                                )
                                            }
                                            inputProps={{ min: 0, max: 100 }}
                                        />
                                    </FormControl>

                                </Box>
                            )}

                        </Paper>

                    ))}

                    <Button
                        variant="contained"
                        onClick={handleSave}
                        disabled={loading}
                        sx={{
                            mt: 2,
                            px: { xs: 3, md: 6 },
                            py: 1.6,
                            borderRadius: 3,
                            fontSize: 16,
                            textTransform: "none",
                            alignSelf: "center",
                            width: isMobile ? "100%" : "auto",
                            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                        }}
                    >
                        {loading ? "Saving..." : "Save Changes"}
                    </Button>

                </Box>

                {/* RIGHT PANEL */}

                <Box
                    sx={{
                        flex: 0.7,
                        p: { xs: 2, md: 3 },
                        borderRadius: 3,
                        background: "linear-gradient(180deg,#f9fbff,#f1f5ff)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 2,
                    }}
                >

                    <Typography
                        variant="h6"
                        fontWeight={700}
                        color={theme.palette.primary.main}
                        textAlign="center"
                    >
                        Active OCR Services
                    </Typography>

                    {apiEnabledOcrs.length === 0 ? (

                        <Typography
                            color="text.secondary"
                            textAlign="center"
                        >
                            No OCRs enabled
                        </Typography>

                    ) : (

                        apiEnabledOcrs.map((ocr) => (

                            <Paper
                                key={ocr.key}
                                sx={{
                                    p: 2,
                                    borderRadius: 3,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    background: "white",
                                    boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
                                }}
                            >

                                <Typography fontWeight={600}>
                                    {ocr.label}
                                </Typography>

                                <Box
                                    sx={{
                                        px: 2,
                                        py: 0.5,
                                        borderRadius: 2,
                                        fontSize: 13,
                                        fontWeight: 600,
                                        background: "linear-gradient(90deg,#4caf50,#81c784)",
                                        color: "white",
                                    }}
                                >
                                    {ocr.accuracy}%
                                </Box>

                            </Paper>

                        ))

                    )}

                </Box>

            </Paper>

        </Box>
    );
};

export default OCRSettingsPage;