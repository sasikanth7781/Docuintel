import AppLayout from "@/components/AppLayout";

export default function UserLayout({ children }: { children: React.ReactNode }) {
    return <AppLayout>{children}</AppLayout>;
}
