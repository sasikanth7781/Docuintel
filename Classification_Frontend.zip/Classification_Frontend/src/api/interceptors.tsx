"use client";
import axios from "axios";
import {
    getAccessToken,
    getRefreshToken,
    setTokens,
    clearTokens,
    isTokenExpired,
} from "@/utils/tokenHelper";

const isBrowser = typeof window !== "undefined";

const api = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL,
});

// =======================
// 🔁 Refresh Token Logic
// =======================
let isRefreshing = false;
let subscribers: Array<(token: string) => void> = [];

function onRefreshed(token: string) {
    subscribers.forEach((cb) => cb(token));
    subscribers = [];
}

function addSubscriber(callback: (token: string) => void) {
    subscribers.push(callback);
}

async function refreshAccessToken(): Promise<string | null> {
    const refreshToken = getRefreshToken();
    console.log("Refresh token:", refreshToken);
    if (!refreshToken) return null;

    try {
        const res = await axios.post(
            `${process.env.NEXT_PUBLIC_API_URL}access_token/`,
            { refresh: refreshToken }
        );

        const newAccessToken = res.data?.access;
        if (newAccessToken) {
            setTokens(newAccessToken, refreshToken);
            return newAccessToken;
        }
        return null;
    } catch (error) {
        clearTokens();

        if (isBrowser && window.location.pathname !== "/auth/login") {
            window.location.href = "/auth/login";
        }

        return null;
    }
}

// =======================
// ✅ Request Interceptor
// =======================
api.interceptors.request.use(async (config) => {
    if (!isBrowser) return config;

    let accessToken = getAccessToken();

    if (accessToken && isTokenExpired(accessToken)) {
        console.log("Access token expired, refreshing...");
        accessToken = await refreshAccessToken();
    }

    if (accessToken) {
        config.headers = {
            ...(config.headers || {}),
            Authorization: `Bearer ${accessToken}`,
        } as any;
    }

    return config;
});

// =======================
// 🔙 Response Interceptor
// =======================
api.interceptors.response.use(
    (response) => response,
    async (error) => {
        if (!isBrowser) return Promise.reject(error);

        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
            if (isRefreshing) {
                return new Promise((resolve) => {
                    addSubscriber((token) => {
                        originalRequest.headers = {
                            ...(originalRequest.headers || {}),
                            Authorization: `Bearer ${token}`,
                        } as any;
                        resolve(api(originalRequest));
                    });
                });
            }

            originalRequest._retry = true;
            isRefreshing = true;

            const newAccessToken = await refreshAccessToken();
            isRefreshing = false;

            if (newAccessToken) {
                onRefreshed(newAccessToken);

                originalRequest.headers = {
                    ...(originalRequest.headers || {}),
                    Authorization: `Bearer ${newAccessToken}`,
                } as any;

                return api(originalRequest);
            }
            else {
                clearTokens();
                return Promise.reject(error);
            }
        }

        return Promise.reject(error);
    }
);

export default api;
