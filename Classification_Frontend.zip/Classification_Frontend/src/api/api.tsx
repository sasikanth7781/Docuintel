import { AxiosResponse } from "axios";
import api from "./interceptors";

export const ENDPIONTS = {
  LOGIN: "Login",
};

interface TypeCallbackFn {
  (data: object | null): void;
}

interface ApiMethods {
  fetchAll: () => Promise<AxiosResponse<unknown>>;
  fetchById: (id: string) => Promise<AxiosResponse<unknown>>;
  create: (newRecord: object) => Promise<AxiosResponse<unknown>>;
  update: (id: string, updatedRecord: object) => Promise<AxiosResponse<unknown>>;
  updatePatch: (updatedRecord: object, id?: string) => Promise<AxiosResponse<unknown>>;
  delete: (id: string) => Promise<AxiosResponse<unknown>>;
  fetchData: (id: string) => Promise<AxiosResponse<unknown>>;
  searchData: (searchCriteria: object) => Promise<AxiosResponse<unknown>>;
  fetchByUserId: (userId: string) => Promise<AxiosResponse<unknown>>;
  fetchFileById: (id: string) => Promise<AxiosResponse<unknown>>;
  fetchFileByParam: (param: object) => Promise<AxiosResponse<unknown>>;
  fetchFile: () => Promise<AxiosResponse<unknown>>;
}

interface CCSCApiEndpointMethods {
  fetchAll: () => Promise<AxiosResponse<unknown>>;
  fetchById: (id: string) => Promise<AxiosResponse<unknown>>;
  create: (newRecord: object) => Promise<AxiosResponse<unknown>>;
  update: (id: string, updatedRecord: object) => Promise<AxiosResponse<unknown>>;
  delete: (id: string) => Promise<AxiosResponse<unknown>>;
}

export const CCSCAPIEndpoint = (endpoint: string): CCSCApiEndpointMethods => {
  const url = process.env.NEXT_PUBLIC_API_URL + endpoint + "/";

  return {
    fetchAll: () => api.get(url),
    fetchById: (id: string) => api.get(url + id),
    create: (newRecord: object) => api.post(url, newRecord),
    update: (id: string, updatedRecord: object) => api.put(url + id, updatedRecord),
    delete: (id: string) => api.delete(url + id),
  };
};

export const CCSCAPIEndpointAndMehtod = (
  endpoint: string,
  methodName: string | null
): ApiMethods => {
  const url = !!methodName
    ? process.env.NEXT_PUBLIC_API_URL + endpoint + "/" + methodName + "/"
    : process.env.NEXT_PUBLIC_API_URL + endpoint + "/";

  return {
    fetchAll: () => api.get(url),
    fetchById: (id: string) => api.get(url + id),
    fetchByUserId: (userId: string) => api.get(`${url}?userId=${userId}`),
    create: (newRecord: object) => api.post(url, newRecord),
    update: (id: string, updatedRecord: object) => api.put(url + id + "/", updatedRecord),
    updatePatch: (updatedRecord: object, id?: string) =>
      id ? api.patch(url + id + "/", updatedRecord) : api.patch(url, updatedRecord),
    delete: (id: string) => api.delete(url + id + "/"),
    fetchData: (id: string) => api.get(url, { params: id }),
    fetchFileById: (id: string) => api.get(url + id, { responseType: "blob" }),
    fetchFileByParam: (param: object) => api.get(url, { params: param, responseType: "blob" }),
    fetchFile: () => api.get(url, { responseType: "blob" }),
    searchData: (searchCriteria: object) => api.get(url, { params: searchCriteria }),
  };
};

export const callGetApiWithData = (
  endpoint: string,
  methodName: string | null,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .searchData(data)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};




// const onResponse = (response: apiResponse): apiResponse => {
//   return response;
// };

// const onResponseError = (error: apiError): Promise<apiError> => {
//   if (
//     error?.response?.status == 401 &&
//     window.location.pathname != "/auth/login"
//   ) {
//     secureLocalStorage.clear();
//     localStorage.clear();
//     secureLocalStorage.removeItem(AppConstant.TOKEN);
//     window.location.href = "/auth/login";
//   }
//   return Promise.reject(error);
// };

// api.interceptors.response.use(onResponse, onResponseError);

export const callPostApiWithData = (
  endpoint: string,
  methodName: string | null,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .create(data)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

export const callDeleteApiWithData = (
  endpoint: string,
  methodName: string | null,
  id: string,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .delete(id)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

export const callPutApiWithData = (
  endpoint: string,
  methodName: string | null,
  id: string,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .update(id, data)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

export const callPatchApiWithData = (
  endpoint: string,
  methodName: string | null,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn,
  id?: string
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .updatePatch(data, id)
    .then((response) => onSuccess(response.data as object))
    .catch((err) => onError(err));
};



export const MultiPartAPIEndpointAndMethod = (
  endpoint: string,
  methodName: string
) => {
  const url = !!methodName
    ? process.env.NEXT_PUBLIC_API_URL + endpoint + "/" + methodName
    : process.env.NEXT_PUBLIC_API_URL + endpoint + "/";

  //const token = getAuthToken();
  const headers = {
    "Content-Type": "multipart/form-data",
    // Authorization: "Bearer " + "" + token,
  };

  return {
    fetchAll: () => api.get(url, { headers: headers }),
    fetchById: (id: string) => api.get(url + "/" + id, { headers: headers }),
    create: (newRecord: object) =>
      api.post(url, newRecord, { headers: headers }),
    update: (id: string, updatedRecord: object) =>
      api.put(url + id, updatedRecord, { headers: headers }),
    delete: (id: string) => api.delete(url + "/" + id, { headers: headers }),
    fetchData: (id: string) => api.get(url, { headers: headers, params: id }),
    searchData: (searchCriteria: object) =>
      api.get(url, { headers: headers, params: searchCriteria }),
  };
};


